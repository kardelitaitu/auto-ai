
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import Orchestrator from '../../core/orchestrator.js';
import { validatePayload, validateTaskExecution } from '../../utils/validator.js';
import metricsCollector from '../../utils/metrics.js';

// Mock Logger Singleton using vi.hoisted
const { mockLogger, mockMetrics } = vi.hoisted(() => {
  return {
    mockLogger: {
      info: vi.fn(),
      debug: vi.fn(),
      warn: vi.fn(),
      error: vi.fn(),
    },
    mockMetrics: {
      recordBrowserDiscovery: vi.fn(),
      recordTaskExecution: vi.fn(),
      getStats: vi.fn(),
      getRecentTasks: vi.fn(),
      getTaskBreakdown: vi.fn(),
      logStats: vi.fn(),
      generateJsonReport: vi.fn(),
    }
  };
});

// Mock dependencies
vi.mock('../../core/sessionManager.js');
vi.mock('../../core/discovery.js');
vi.mock('../../core/automator.js');
vi.mock('../../utils/metrics.js', () => ({
  default: mockMetrics
}));
vi.mock('../../utils/logger.js', () => ({
  createLogger: vi.fn(() => mockLogger),
}));
vi.mock('../../utils/configLoader.js', () => ({
  getTimeoutValue: vi.fn(),
  getSettings: vi.fn(),
}));
vi.mock('../../utils/envLoader.js', () => ({
  isDevelopment: vi.fn(() => false),
}));

// Mock validator
vi.mock('../../utils/validator.js', () => ({
  validateTaskExecution: vi.fn(() => ({ isValid: true })),
  validatePayload: vi.fn(() => ({ isValid: true })),
}));

describe('Orchestrator Coverage Extensions', () => {
  let orchestrator;
  let mockSessionManager;
  let mockDiscovery;
  let mockAutomator;

  beforeEach(() => {
    vi.clearAllMocks();
    orchestrator = new Orchestrator();
    mockSessionManager = orchestrator.sessionManager;
    mockDiscovery = orchestrator.discovery;
    mockAutomator = orchestrator.automator;

    // Default setups
    Object.defineProperty(mockSessionManager, 'activeSessionsCount', {
      configurable: true,
      get: vi.fn(() => 0),
    });
    mockSessionManager.getAllSessions.mockReturnValue([]);
    mockSessionManager.findAndOccupyIdleWorker.mockResolvedValue({ id: 'w1' });
    mockSessionManager.releaseWorker.mockResolvedValue();
    mockSessionManager.registerPage.mockResolvedValue();
    mockSessionManager.unregisterPage.mockResolvedValue();
    
    // Ensure validator mocks are reset
    if (vi.isMockFunction(validateTaskExecution)) {
      validateTaskExecution.mockReturnValue({ isValid: true });
    }
    if (vi.isMockFunction(validatePayload)) {
      validatePayload.mockReturnValue({ isValid: true });
    }
  });

  describe('executeTask (Coverage)', () => {
    it('should execute successfully when task module is valid', async () => {
      const task = { taskName: 'coverage_valid_task', payload: { foo: 'bar' } };
      const session = { id: 's1', browserInfo: 'test' };
      const page = {};

      await orchestrator.executeTask(task, page, session);

      expect(mockMetrics.recordTaskExecution).toHaveBeenCalledWith(
        'coverage_valid_task',
        expect.any(Number),
        true, // success
        's1',
        null // error
      );
    });

    it('should throw error if task module has no default export', async () => {
      const task = { taskName: 'coverage_no_default_task', payload: {} };
      const session = { id: 's1', browserInfo: 'test' };
      const page = {};

      await orchestrator.executeTask(task, page, session);

      expect(mockLogger.error).toHaveBeenCalledWith(
        expect.stringContaining("Error executing task"),
        expect.objectContaining({
          message: expect.stringContaining("does not export a default function")
        })
      );
      expect(mockMetrics.recordTaskExecution).toHaveBeenCalledWith(
        expect.anything(),
        expect.anything(),
        false, // success
        expect.anything(),
        expect.anything() // error
      );
    });

    it('should throw error if augmented payload validation fails', async () => {
      const task = { taskName: 'coverage_valid_task', payload: {} };
      const session = { id: 's1', browserInfo: 'test' };
      const page = {};

      // First validation passes (default), second fails
      validatePayload.mockReturnValueOnce({ isValid: false, errors: ['Invalid augmented payload'] });

      await orchestrator.executeTask(task, page, session);

      expect(mockLogger.error).toHaveBeenCalledWith(
        expect.stringContaining("Error executing task"),
        expect.objectContaining({
          message: expect.stringContaining("Augmented payload validation failed")
        })
      );
    });
  });

  describe('processChecklistForSession (Edge Cases)', () => {
    it('should NOT close shared context if shutting down', async () => {
      orchestrator.isShuttingDown = true;
      
      const mockContext = { 
        newPage: vi.fn().mockResolvedValue({ close: vi.fn() }), 
        close: vi.fn().mockResolvedValue() 
      };
      
      const mockSession = { 
        id: 's1', 
        browser: { 
          contexts: () => [], 
          newContext: vi.fn().mockResolvedValue(mockContext) 
        },
        workers: [{ id: 'w1' }] 
      };

      // Execute with empty list to skip loop, just testing finally block
      await orchestrator.processChecklistForSession(mockSession, []);
      
      expect(mockContext.close).not.toHaveBeenCalled();
    });

    it('should close shared context if NOT shutting down', async () => {
      orchestrator.isShuttingDown = false;
      
      const mockContext = { 
        newPage: vi.fn().mockResolvedValue({ close: vi.fn() }), 
        close: vi.fn().mockResolvedValue() 
      };
      
      const mockSession = { 
        id: 's1', 
        browser: { 
          contexts: () => [], 
          newContext: vi.fn().mockResolvedValue(mockContext) 
        },
        workers: [{ id: 'w1' }] 
      };

      await orchestrator.processChecklistForSession(mockSession, []);
      
      expect(mockContext.close).toHaveBeenCalled();
    });
  });

  describe('processTasks (Event Emission)', () => {
    it('should emit tasksProcessed and allTasksComplete when queue finishes', async () => {
      orchestrator.taskQueue = [{ taskName: 't1' }];
      vi.spyOn(mockSessionManager, 'activeSessionsCount', 'get').mockReturnValue(1);
      mockSessionManager.getAllSessions.mockReturnValue([{ 
        id: 's1', 
        browser: { contexts: () => [], newContext: vi.fn().mockResolvedValue({ close: vi.fn() }) },
        workers: [] 
      }]);
      
      // Spy on processChecklistForSession
      vi.spyOn(orchestrator, 'processChecklistForSession').mockResolvedValue();
      
      const tasksProcessedSpy = vi.fn();
      const allTasksCompleteSpy = vi.fn();
      
      orchestrator.on('tasksProcessed', tasksProcessedSpy);
      orchestrator.on('allTasksComplete', allTasksCompleteSpy);
      
      await orchestrator.processTasks();
      
      expect(tasksProcessedSpy).toHaveBeenCalled();
      expect(allTasksCompleteSpy).toHaveBeenCalled();
    });
  });

  describe('startDiscovery (Edge Cases)', () => {
    it('should handle no endpoints found', async () => {
      mockDiscovery.discoverBrowsers.mockResolvedValue([]);
      
      await orchestrator.startDiscovery();
      
      expect(mockLogger.warn).toHaveBeenCalledWith(expect.stringContaining('No browser endpoints discovered'));
      expect(mockSessionManager.addSession).not.toHaveBeenCalled();
    });

    it('should skip browser with no ws endpoint', async () => {
      mockDiscovery.discoverBrowsers.mockResolvedValue([
        { ws: null, windowName: 'NoWS' }
      ]);
      
      await orchestrator.startDiscovery();
      
      expect(mockLogger.warn).toHaveBeenCalledWith(expect.stringContaining("has no 'ws' endpoint"));
      expect(mockSessionManager.addSession).not.toHaveBeenCalled();
    });

    it('should handle URL parsing error for port', async () => {
      mockDiscovery.discoverBrowsers.mockResolvedValue([
        { ws: 'invalid-url', windowName: 'BadURL' }
      ]);
      
      mockAutomator.connectToBrowser.mockResolvedValue({});
      
      await orchestrator.startDiscovery();
      
      // Should still add session, just maybe without port in name
      expect(mockSessionManager.addSession).toHaveBeenCalledWith(expect.anything(), 'BadURL');
    });

    it('should handle top-level discovery error', async () => {
      mockDiscovery.loadConnectors.mockRejectedValue(new Error('Load failed'));
      
      await orchestrator.startDiscovery();
      
      expect(mockLogger.error).toHaveBeenCalledWith('Browser discovery failed:', 'Load failed');
    });

    it('should handle mix of successful and failed connections', async () => {
      mockDiscovery.discoverBrowsers.mockResolvedValue([
        { ws: 'ws://success', windowName: 'Success' },
        { ws: 'ws://fail', windowName: 'Fail' }
      ]);
      
      mockAutomator.connectToBrowser.mockImplementation((ws) => {
        if (ws === 'ws://success') return Promise.resolve({});
        return Promise.reject(new Error('Connect failed'));
      });
      
      vi.spyOn(mockSessionManager, 'activeSessionsCount', 'get').mockReturnValue(1);
      
      await orchestrator.startDiscovery();
      
      expect(mockSessionManager.addSession).toHaveBeenCalledTimes(1);
      expect(mockSessionManager.addSession).toHaveBeenCalledWith(expect.anything(), 'Success');
    });
  });

  describe('Metrics Passthrough', () => {
    it('should delegate getMetrics', () => {
      mockMetrics.getStats.mockReturnValue({ total: 10 });
      expect(orchestrator.getMetrics()).toEqual({ total: 10 });
    });

    it('should delegate getRecentTasks', () => {
      mockMetrics.getRecentTasks.mockReturnValue([]);
      expect(orchestrator.getRecentTasks(5)).toEqual([]);
      expect(mockMetrics.getRecentTasks).toHaveBeenCalledWith(5);
    });

    it('should delegate getTaskBreakdown', () => {
      mockMetrics.getTaskBreakdown.mockReturnValue({});
      expect(orchestrator.getTaskBreakdown()).toEqual({});
    });

    it('should delegate logMetrics', () => {
      orchestrator.logMetrics();
      expect(mockMetrics.logStats).toHaveBeenCalled();
    });
  });

  describe('Helper Methods', () => {
    it('should wait for specified time in _sleep', async () => {
      vi.useFakeTimers();
      const promise = orchestrator._sleep(1000);
      vi.advanceTimersByTime(1000);
      await expect(promise).resolves.toBeUndefined();
      vi.useRealTimers();
    });
  });

  describe('addTask (Validation & Debounce)', () => {
    it('should throw error for invalid task name', () => {
      expect(() => orchestrator.addTask(null)).toThrow('Invalid task name provided');
      expect(() => orchestrator.addTask('')).toThrow('Invalid task name provided');
      expect(() => orchestrator.addTask(123)).toThrow('Invalid task name provided');
    });

    it('should throw error for invalid payload', () => {
      validatePayload.mockReturnValueOnce({ isValid: false, errors: ['Invalid field'] });

      expect(() => orchestrator.addTask('task1', { bad: 'data' })).toThrow('Invalid task payload');
    });

    it('should debounce processTasks calls', async () => {
      vi.useFakeTimers();
      const processTasksSpy = vi.spyOn(orchestrator, 'processTasks').mockResolvedValue();

      orchestrator.addTask('task1');
      orchestrator.addTask('task2');
      orchestrator.addTask('task3');

      expect(processTasksSpy).not.toHaveBeenCalled();

      vi.advanceTimersByTime(50);

      expect(processTasksSpy).toHaveBeenCalledTimes(1);
      vi.useRealTimers();
    });
  });

  describe('executeTask (Failure Modes)', () => {
    it('should handle missing task module gracefully', async () => {
      const task = { taskName: 'nonExistentTask', payload: {} };
      const session = { id: 's1', browserInfo: 'test' };
      const page = {};

      await orchestrator.executeTask(task, page, session);

      expect(mockLogger.error).toHaveBeenCalledWith(
        expect.stringContaining("Error executing task 'nonExistentTask'"),
        expect.anything()
      );
    });

    it('should handle task module with no default export', async () => {
       // Just verify that code path exists if we can't mock module easily
    });
  });

  describe('shutdown', () => {
    it('should handle force shutdown', async () => {
       const waitForTasksSpy = vi.spyOn(orchestrator, 'waitForTasksToComplete').mockResolvedValue();
       vi.spyOn(orchestrator.automator, 'shutdown').mockResolvedValue();
       vi.spyOn(orchestrator.sessionManager, 'shutdown').mockResolvedValue();

       await orchestrator.shutdown(true);

       expect(waitForTasksSpy).not.toHaveBeenCalled();
       expect(orchestrator.isShuttingDown).toBe(true);
       expect(orchestrator.sessionManager.shutdown).toHaveBeenCalled();
       expect(orchestrator.automator.shutdown).toHaveBeenCalled();
    });

    it('should handle normal shutdown', async () => {
       const waitForTasksSpy = vi.spyOn(orchestrator, 'waitForTasksToComplete').mockResolvedValue();
       vi.spyOn(orchestrator.automator, 'shutdown').mockResolvedValue();
       vi.spyOn(orchestrator.sessionManager, 'shutdown').mockResolvedValue();

       await orchestrator.shutdown(false);

       expect(waitForTasksSpy).toHaveBeenCalled();
       expect(orchestrator.isShuttingDown).toBe(true);
    });
  });
});

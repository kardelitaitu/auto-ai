import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import Automator from '../../core/automator.js';
import { chromium } from 'playwright';

const mocks = vi.hoisted(() => {
    return {
        logger: {
            info: vi.fn(),
            warn: vi.fn(),
            error: vi.fn(),
            debug: vi.fn()
        }
    };
});

vi.mock('playwright', () => ({
    chromium: {
        connectOverCDP: vi.fn(),
        launch: vi.fn()
    }
}));

vi.mock('../../utils/configLoader.js', () => ({
    getTimeoutValue: vi.fn((key, defaultVal) => Promise.resolve(defaultVal))
}));

vi.mock('../../utils/logger.js', () => ({
    createLogger: () => mocks.logger,
    logger: mocks.logger
}));

// Mock retry utility to just execute the function
vi.mock('../../utils/retry.js', () => ({
    withRetry: vi.fn(async (fn) => await fn())
}));

describe('Automator', () => {
    let automator;
    let mockBrowser;

    beforeEach(() => {
        vi.clearAllMocks();
        // Use fake timers to control setInterval
        vi.useFakeTimers();
        
        automator = new Automator();
        mockBrowser = {
            isConnected: vi.fn().mockReturnValue(true),
            close: vi.fn().mockResolvedValue(),
            on: vi.fn(),
            contexts: () => [],
            newPage: vi.fn()
        };
        chromium.connectOverCDP.mockResolvedValue(mockBrowser);
    });

    afterEach(() => {
        automator.stopHealthChecks();
        vi.useRealTimers();
    });

    describe('Connection Management', () => {
        it('should connect to browser', async () => {
            const browser = await automator.connectToBrowser('ws://test');
            expect(browser).toBeDefined();
            expect(automator.connections.has('ws://test')).toBe(true);
            expect(automator.getConnectionCount()).toBe(1);
            expect(mocks.logger.info).toHaveBeenCalledWith(expect.stringContaining('Successfully connected'));
        });

        it('should fail to connect if browser is not connected', async () => {
             const disconnectedBrowser = {
                 isConnected: vi.fn().mockReturnValue(false),
                 close: vi.fn()
             };
             chromium.connectOverCDP.mockResolvedValue(disconnectedBrowser);
             
             await expect(automator.connectToBrowser('ws://test')).rejects.toThrow('Browser is not connected');
        });

        it('should reconnect', async () => {
            await automator.connectToBrowser('ws://test');
            const newBrowser = await automator.reconnect('ws://test');
            expect(chromium.connectOverCDP).toHaveBeenCalledTimes(2);
            expect(newBrowser).toBeDefined();
        });
        
        it('should handle reconnect error when closing old connection', async () => {
            await automator.connectToBrowser('ws://test');
            const oldBrowser = automator.getBrowser('ws://test');
            oldBrowser.close.mockRejectedValue(new Error('Close error'));
            
            await automator.reconnect('ws://test');
            expect(mocks.logger.debug).toHaveBeenCalledWith('Error closing old connection:', 'Close error');
        });

        it('should close all connections', async () => {
            await automator.connectToBrowser('ws://test1');
            await automator.connectToBrowser('ws://test2');

            await automator.closeAll();

            expect(mockBrowser.close).toHaveBeenCalledTimes(2);
            expect(automator.connections.size).toBe(0);
        });
        
        it('should handle errors during closeAll', async () => {
            await automator.connectToBrowser('ws://test');
            const browser = automator.getBrowser('ws://test');
            browser.close.mockRejectedValue(new Error('Close failed'));
            
            await automator.closeAll();
            expect(mocks.logger.error).toHaveBeenCalledWith(expect.stringContaining('Error closing browser'), 'Close failed');
        });
        
        it('should shutdown gracefully', async () => {
            const spy = vi.spyOn(automator, 'closeAll');
            await automator.shutdown();
            expect(spy).toHaveBeenCalled();
            expect(mocks.logger.info).toHaveBeenCalledWith('Automator shutting down...');
        });
    });

    describe('Getters and Stats', () => {
        beforeEach(async () => {
            await automator.connectToBrowser('ws://test1');
        });

        it('should get browser by endpoint', () => {
            expect(automator.getBrowser('ws://test1')).toBe(mockBrowser);
            expect(automator.getBrowser('ws://invalid')).toBeNull();
        });

        it('should check if healthy', () => {
            expect(automator.isHealthy('ws://test1')).toBe(true);
            expect(automator.isHealthy('ws://invalid')).toBe(false);
        });

        it('should get connected endpoints', () => {
            expect(automator.getConnectedEndpoints()).toEqual(['ws://test1']);
        });

        it('should get connection count', () => {
            expect(automator.getConnectionCount()).toBe(1);
        });

        it('should get healthy connection count', () => {
            expect(automator.getHealthyConnectionCount()).toBe(1);
            
            // Mark as unhealthy
            automator.connections.get('ws://test1').healthy = false;
            expect(automator.getHealthyConnectionCount()).toBe(0);
        });

        it('should get stats', () => {
            const stats = automator.getStats();
            expect(stats.totalConnections).toBe(1);
            expect(stats.healthyConnections).toBe(1);
            expect(stats.unhealthyConnections).toBe(0);
            expect(stats.connections[0].endpoint).toBe('ws://test1');
        });
    });

    describe('Health Checks Loop', () => {
        it('should start health checks', async () => {
            await automator.startHealthChecks(100);
            expect(automator.healthCheckInterval).toBeDefined();
            expect(mocks.logger.info).toHaveBeenCalledWith(expect.stringContaining('Started health check monitoring'));
        });
        
        it('should start health checks with default interval', async () => {
            await automator.startHealthChecks();
            expect(automator.healthCheckInterval).toBeDefined();
            expect(mocks.logger.info).toHaveBeenCalledWith(expect.stringContaining('Started health check monitoring'));
        });
        
        it('should not start health checks if already running', async () => {
            await automator.startHealthChecks(100);
            const interval = automator.healthCheckInterval;
            await automator.startHealthChecks(100);
            expect(automator.healthCheckInterval).toBe(interval);
            expect(mocks.logger.warn).toHaveBeenCalledWith('Health checks already running');
        });

        it('should perform periodic health checks', async () => {
            await automator.connectToBrowser('ws://test');
            const spy = vi.spyOn(automator, 'testConnection');
            
            // Force last check to be old enough
            const conn = automator.connections.get('ws://test');
            conn.lastHealthCheck = Date.now() - 11000;

            await automator.startHealthChecks(50);
            
            await vi.advanceTimersByTimeAsync(100);
            
            expect(spy).toHaveBeenCalledWith(mockBrowser);
        });

        it('should handle failed health checks and trigger background reconnect', async () => {
            await automator.connectToBrowser('ws://test');
            
            // Mock testConnection to fail
            vi.spyOn(automator, 'testConnection').mockRejectedValue(new Error('Connection lost'));
            const reconnectSpy = vi.spyOn(automator, 'attemptBackgroundReconnect');

            const conn = automator.connections.get('ws://test');
            conn.lastHealthCheck = Date.now() - 11000;

            await automator.startHealthChecks(50);
            await vi.advanceTimersByTimeAsync(100);

            expect(conn.healthy).toBe(false);
            expect(mocks.logger.error).toHaveBeenCalledWith(expect.stringContaining('Health check failed'), 'Connection lost');
            expect(reconnectSpy).toHaveBeenCalledWith('ws://test', conn);
        });

        it('should recover from unhealthy state', async () => {
             await automator.connectToBrowser('ws://test');
             const conn = automator.connections.get('ws://test');
             conn.healthy = false;
             conn.lastHealthCheck = Date.now() - 11000;
             
             // testConnection succeeds by default mock
             
             await automator.startHealthChecks(50);
             await vi.advanceTimersByTimeAsync(100);
             
             expect(conn.healthy).toBe(true);
             expect(mocks.logger.info).toHaveBeenCalledWith(expect.stringContaining('Health check recovered'));
        });

        it('should not check recently checked connections', async () => {
            await automator.connectToBrowser('ws://test');
            const spy = vi.spyOn(automator, 'testConnection');
            
            // Last check was just now
            const conn = automator.connections.get('ws://test');
            conn.lastHealthCheck = Date.now();

            await automator.startHealthChecks(50);
            await vi.advanceTimersByTimeAsync(100);
            
            expect(spy).not.toHaveBeenCalled();
        });
        
        it('should not run checks if shutting down', async () => {
            await automator.connectToBrowser('ws://test');
            const spy = vi.spyOn(automator, 'testConnection');
            
            automator.isShuttingDown = true;
            await automator.startHealthChecks(50);
            await vi.advanceTimersByTimeAsync(100);
            
            expect(spy).not.toHaveBeenCalled();
        });
    });

    describe('Background Reconnect', () => {
        it('should stop background reconnect after max attempts', async () => {
             const conn = {
                 reconnectAttempts: 3,
                 endpoint: 'ws://test'
             };
             automator.connections.set('ws://test', conn);
             
             await automator.attemptBackgroundReconnect('ws://test', conn);
             
             expect(mocks.logger.error).toHaveBeenCalledWith(expect.stringContaining('Max reconnect attempts reached'));
             expect(automator.connections.has('ws://test')).toBe(false);
        });
        
        it('should handle background reconnect failure', async () => {
             const conn = {
                 reconnectAttempts: 0,
                 endpoint: 'ws://test'
             };
             automator.connections.set('ws://test', conn);
             
             // Mock reconnect failure
             vi.spyOn(automator, 'reconnect').mockRejectedValue(new Error('Reconnect failed'));
             
             await automator.attemptBackgroundReconnect('ws://test', conn);
             
             expect(mocks.logger.error).toHaveBeenCalledWith(expect.stringContaining('Background reconnect failed'), 'Reconnect failed');
             expect(conn.reconnectAttempts).toBe(1);
        });

        it('should increment reconnect attempts', async () => {
             const conn = {
                 reconnectAttempts: 0,
                 endpoint: 'ws://test'
             };
             automator.connections.set('ws://test', conn);
             
             vi.spyOn(automator, 'reconnect').mockResolvedValue({});
             
             await automator.attemptBackgroundReconnect('ws://test', conn);
             
             expect(conn.reconnectAttempts).toBe(1);
             expect(mocks.logger.info).toHaveBeenCalledWith(expect.stringContaining('Background reconnection attempt 1'));
        });
    });

    describe('Comprehensive Health Checks', () => {
        it('should check network connectivity successfully', async () => {
            const mockTestPage = {
                goto: vi.fn().mockResolvedValue(),
            };
            const mockContext = {
                newPage: vi.fn().mockResolvedValue(mockTestPage),
                close: vi.fn().mockResolvedValue()
            };
            chromium.launch.mockResolvedValue(mockContext);

            const result = await automator.checkNetworkConnectivity();
            
            expect(result.healthy).toBe(true);
            expect(result.latency).toBeDefined();
            expect(mockTestPage.goto).toHaveBeenCalledWith('https://x.com', expect.any(Object));
        });

        it('should handle network connectivity check failure', async () => {
            chromium.launch.mockRejectedValue(new Error('Launch failed'));

            const result = await automator.checkNetworkConnectivity();
            
            expect(result.healthy).toBe(false);
            expect(result.error).toBe('Launch failed');
        });

        it('should check page responsive successfully', async () => {
            const mockPage = {
                isClosed: () => false,
                evaluate: vi.fn().mockResolvedValue({
                    documentReady: 'complete',
                    title: 'Test',
                    bodyExists: true
                })
            };

            const result = await automator.checkPageResponsive(mockPage);
            
            expect(result.healthy).toBe(true);
            expect(result.documentState).toBe('complete');
        });

        it('should handle closed page in responsive check', async () => {
            const mockPage = {
                isClosed: () => true
            };

            const result = await automator.checkPageResponsive(mockPage);
            
            expect(result.healthy).toBe(false);
            expect(result.error).toBe('Page is closed or null');
        });

        it('should handle evaluate failure in responsive check', async () => {
            const mockPage = {
                isClosed: () => false,
                evaluate: vi.fn().mockRejectedValue(new Error('Eval failed'))
            };

            const result = await automator.checkPageResponsive(mockPage);
            
            expect(result.healthy).toBe(false);
            // The implementation swallows the error message in the inner catch block
            // and returns a status object with healthy: false
            expect(result.documentState).toBeUndefined();
        });

        it('should handle synchronous error in responsive check', async () => {
            const mockPage = {
                isClosed: () => false,
                // evaluate missing or throwing synchronously
                get evaluate() { throw new Error('Sync error'); }
            };

            const result = await automator.checkPageResponsive(mockPage);
            
            expect(result.healthy).toBe(false);
            expect(result.error).toBe('Sync error');
        });

        it('should check connection health (comprehensive)', async () => {
            await automator.connectToBrowser('ws://test');
            
            // Mock sub-checks
            vi.spyOn(automator, 'checkNetworkConnectivity').mockResolvedValue({ healthy: true });
            vi.spyOn(automator, 'checkPageResponsive').mockResolvedValue({ healthy: true });
            
            // Force network check
            const mathRandomSpy = vi.spyOn(Math, 'random').mockReturnValue(0.1);

            const result = await automator.checkConnectionHealth('ws://test', {});
            
            expect(result.healthy).toBe(true);
            expect(result.checks.browserConnection).toBe(true);
            expect(result.checks.network).toBeDefined();
            expect(result.checks.page).toBeDefined();
            
            mathRandomSpy.mockRestore();
        });

        it('should handle disconnected browser in connection health check', async () => {
            await automator.connectToBrowser('ws://test');
            mockBrowser.isConnected.mockReturnValue(false);
            
            const result = await automator.checkConnectionHealth('ws://test');
            
            expect(result.healthy).toBe(false);
            expect(result.checks.browserConnection).toBe(false);
        });

        it('should handle error when checking browser connection', async () => {
            await automator.connectToBrowser('ws://test');
            mockBrowser.isConnected.mockImplementation(() => {
                throw new Error('Connection error');
            });
            
            const result = await automator.checkConnectionHealth('ws://test');
            
            expect(result.healthy).toBe(false);
            expect(result.checks.browserConnection).toBe(false);
        });

        it('should execute evaluate callback logic', async () => {
            // This test ensures the code inside page.evaluate is valid
            // by extracting it and running it in a simulated environment
            const mockPage = {
                isClosed: () => false,
                evaluate: vi.fn((fn) => {
                    // Create a minimal document mock for the callback
                    global.document = {
                        readyState: 'complete',
                        title: 'Test Title',
                        body: {}
                    };
                    try {
                        return Promise.resolve(fn());
                    } finally {
                        delete global.document;
                    }
                })
            };

            const result = await automator.checkPageResponsive(mockPage);
            
            expect(result.healthy).toBe(true);
            expect(result.documentState).toBe('complete');
            expect(result.title).toBe('Test Title');
        });
        
        it('should update connection info after health check', async () => {
             await automator.connectToBrowser('ws://test');
             const conn = automator.connections.get('ws://test');
             
             await automator.checkConnectionHealth('ws://test');
             
             expect(conn.lastHealthCheck).toBeDefined();
        });

        it('should handle getHealthSummary with mixed health', async () => {
             await automator.connectToBrowser('ws://healthy');
             await automator.connectToBrowser('ws://unhealthy');
             
             vi.spyOn(automator, 'checkConnectionHealth')
                .mockImplementation(async (endpoint) => {
                    return { healthy: endpoint === 'ws://healthy' };
                });
                
             const summary = await automator.getHealthSummary();
             expect(summary.total).toBe(2);
             expect(summary.healthy).toBe(1);
             expect(summary.unhealthy).toBe(1);
        });
    });

    describe('Connection Recovery', () => {
        beforeEach(async () => {
            await automator.connectToBrowser('ws://test');
        });

        it('should recover if browser is connected', async () => {
            const result = await automator.recoverConnection('ws://test');
            expect(result.successful).toBe(true);
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'browser_check', success: true }));
        });

        it('should attempt page reload if page provided', async () => {
            const mockPage = {
                isClosed: () => false,
                reload: vi.fn().mockResolvedValue()
            };

            const result = await automator.recoverConnection('ws://test', mockPage);
            
            expect(result.successful).toBe(true);
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'page_reload', success: true }));
        });

        it('should fallback to home navigation if reload fails', async () => {
            const mockPage = {
                isClosed: () => false,
                reload: vi.fn().mockRejectedValue(new Error('Reload failed')),
                goto: vi.fn().mockResolvedValue()
            };

            const result = await automator.recoverConnection('ws://test', mockPage);
            
            expect(result.successful).toBe(true);
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'page_reload', success: false }));
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'navigate_home', success: true }));
        });
        
        it('should report failure if navigation also fails', async () => {
            const mockPage = {
                isClosed: () => false,
                reload: vi.fn().mockRejectedValue(new Error('Reload failed')),
                goto: vi.fn().mockRejectedValue(new Error('Goto failed'))
            };

            const result = await automator.recoverConnection('ws://test', mockPage);
            
            // Still successful because browser_check passed
            expect(result.successful).toBe(true);
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'navigate_home', success: false }));
        });

        it('should attempt reconnect if browser disconnected', async () => {
            mockBrowser.isConnected.mockReturnValue(false);
            vi.spyOn(automator, 'reconnect').mockResolvedValue({});

            const result = await automator.recoverConnection('ws://test');
            
            expect(result.successful).toBe(true);
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'reconnect', success: true }));
        });

        it('should report failure if reconnect fails', async () => {
            mockBrowser.isConnected.mockReturnValue(false);
            vi.spyOn(automator, 'reconnect').mockRejectedValue(new Error('Reconnect failed'));

            const result = await automator.recoverConnection('ws://test');
            
            expect(result.successful).toBe(false);
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'reconnect', success: false }));
        });
        
        it('should handle generic errors during recovery', async () => {
            // Force an error accessing browser property
            const mockThrowingBrowser = {
                get isConnected() { throw new Error('Browser error'); }
            };
            automator.connections.set('ws://test', { browser: mockThrowingBrowser });
            
            const result = await automator.recoverConnection('ws://test');
            expect(result.successful).toBe(false);
            expect(result.steps).toContainEqual(expect.objectContaining({ step: 'initial_check', success: false, error: 'Browser error' }));
        });

        it('should handle error during initial recovery check', async () => {
            const conn = automator.connections.get('ws://test');
            // Mock isConnected to throw
            mockBrowser.isConnected.mockImplementation(() => {
                throw new Error('Unexpected error');
            });
            
            const result = await automator.recoverConnection('ws://test');
            
            expect(result.successful).toBe(false);
            expect(result.steps).toContainEqual(expect.objectContaining({ 
                step: 'initial_check', 
                success: false, 
                error: 'Unexpected error' 
            }));
        });
    });

    describe('Health Summary', () => {
        it('should generate health summary', async () => {
            await automator.connectToBrowser('ws://test1');
            await automator.connectToBrowser('ws://test2');
            
            vi.spyOn(automator, 'checkConnectionHealth').mockResolvedValue({ healthy: true });
            
            const summary = await automator.getHealthSummary();
            
            expect(summary.total).toBe(2);
            expect(summary.healthy).toBe(2);
            expect(summary.connections['ws://test1']).toBeDefined();
        });

        it('should handle unhealthy connections in summary', async () => {
            await automator.connectToBrowser('ws://test1');
            const conn = automator.connections.get('ws://test1');
            // Mock browser to be disconnected so checkConnectionHealth returns unhealthy
            conn.browser.isConnected.mockReturnValue(false);
            
            const summary = await automator.getHealthSummary();
            expect(summary.healthy).toBe(0);
            expect(summary.unhealthy).toBe(1);
        });
    });

    describe('Coverage Edge Cases', () => {
        it('should handle reconnect when connection exists but browser is missing', async () => {
            // Setup connection info without browser
            automator.connections.set('ws://missing-browser', {
                endpoint: 'ws://missing-browser',
                browser: null
            });

            const browser = await automator.reconnect('ws://missing-browser');
            expect(browser).toBeDefined();
            // Should verify that old connection cleanup was skipped (no close call on null)
            // Implicitly verified by lack of error
        });

        it('should handle closeAll with invalid browser object', async () => {
            // Setup connection with malformed browser object
            automator.connections.set('ws://invalid-browser', {
                endpoint: 'ws://invalid-browser',
                browser: { notClose: 'foo' } // No close method
            });

            await automator.closeAll();
            // Should not throw and should not call close
            // Logger debug should not be called for this one
            expect(mocks.logger.debug).not.toHaveBeenCalledWith(expect.stringContaining('Closed connection to ws://invalid-browser'));
        });

        it('should handle checkConnectionHealth with unknown endpoint', async () => {
            const result = await automator.checkConnectionHealth('ws://unknown');
            expect(result.healthy).toBe(false); // browserConnection false by default
            expect(result.endpoint).toBe('ws://unknown');
            // Should not throw when accessing connectionInfo (which is undefined)
        });
    });
});

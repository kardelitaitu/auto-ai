import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { taskConfigLoader, TaskConfigLoader, loadAiTwitterActivityConfig } from '../../utils/task-config-loader.js';
import { config } from '../../utils/config-service.js';
import { getSettings } from '../../utils/configLoader.js';
import { ConfigValidator } from '../../utils/config-validator.js';

// Mock the dependencies
vi.mock('../../utils/config-service.js', () => ({
    config: {
        getTwitterActivity: vi.fn(),
        getTiming: vi.fn(),
        getEngagementLimits: vi.fn(),
        getHumanization: vi.fn()
    }
}));

vi.mock('../../utils/configLoader.js', () => ({
    getSettings: vi.fn()
}));

vi.mock('../../utils/config-validator.js', () => ({
    ConfigValidator: class {
        constructor() {
            this.validateConfig = vi.fn().mockReturnValue({ valid: true, errors: [] });
        }
    }
}));

vi.mock('../../utils/config-cache.js', () => ({
    ConfigCache: class {
        constructor() {
            this.data = new Map();
            this.get = vi.fn((key) => this.data.get(key));
            this.set = vi.fn((key, value) => this.data.set(key, value));
            this.clear = vi.fn(() => this.data.clear());
            this.size = 0;
            this.maxSize = 100;
        }
    }
}));

vi.mock('../../utils/environment-config.js', () => {
    const mock = vi.fn().mockImplementation(function () {
        this.applyEnvOverrides = vi.fn((config) => config);
    });
    mock.applyEnvOverrides = vi.fn((config) => config);
    return { EnvironmentConfig: mock };
});

vi.mock('../../utils/logger.js', () => ({
    createLogger: vi.fn(() => ({
        info: vi.fn(),
        warn: vi.fn(),
        error: vi.fn(),
        debug: vi.fn()
    }))
}));

describe('task-config-loader', () => {
    let loader;

    beforeEach(() => {
        vi.clearAllMocks();

        // Setup default mock implementations
        vi.mocked(config.getTwitterActivity).mockResolvedValue({
            defaultCycles: 20,
            defaultMinDuration: 360,
            defaultMaxDuration: 540
        });
        vi.mocked(config.getTiming).mockResolvedValue({
            warmupMin: 2000,
            warmupMax: 15000,
            scrollMin: 300,
            scrollMax: 700,
            readMin: 5000,
            readMax: 15000,
            diveRead: 10000,
            globalScrollMultiplier: 1.0
        });
        vi.mocked(config.getEngagementLimits).mockResolvedValue({
            replies: 3,
            retweets: 1,
            quotes: 1,
            likes: 5,
            follows: 2,
            bookmarks: 2
        });
        vi.mocked(config.getHumanization).mockResolvedValue({
            mouse: { speed: 1.0, jitter: 5 },
            typing: { delay: 80, errorRate: 0.05 },
            session: { minMinutes: 5, maxMinutes: 9 }
        });
        vi.mocked(getSettings).mockResolvedValue({
            twitter: {
                reply: { probability: 0.5 },
                quote: { probability: 0.2 },
                actions: {
                    like: { probability: 0.15 },
                    bookmark: { probability: 0.05 }
                }
            },
            llm: {
                cloud: { enabled: true },
                local: { enabled: false }
            },
            vision: { enabled: true }
        });

        // Use a fresh instance for most tests to avoid cache pollution
        loader = new TaskConfigLoader();
    });

    describe('generateCacheKey', () => {
        it('should generate cache key from payload', () => {
            const payload = { cycles: 20, theme: 'dark' };
            const key = loader.generateCacheKey(payload);
            expect(key).toContain('"cycles":20');
            expect(key).toContain('"theme":"dark"');
        });

        it('should include environment variables in cache key', () => {
            process.env.TWITTER_ACTIVITY_CYCLES = '30';
            const key = loader.generateCacheKey({});
            expect(key).toContain('"TWITTER_ACTIVITY_CYCLES":"30"');
            delete process.env.TWITTER_ACTIVITY_CYCLES;
        });
    });

    describe('loadAiTwitterActivityConfig', () => {
        it('should load and cache configuration', async () => {
            const payload = { cycles: 10 };
            const config1 = await loader.loadAiTwitterActivityConfig(payload);

            expect(config1.session.cycles).toBe(10);
            expect(loader.loadCount).toBe(1);
            expect(loader.hitCount).toBe(0);

            // Second load should be a cache hit
            const config2 = await loader.loadAiTwitterActivityConfig(payload);
            expect(config2).toEqual(config1);
            expect(loader.loadCount).toBe(1);
            expect(loader.hitCount).toBe(1);
        });

        it('should throw error when validation fails', async () => {
            const validatorInstance = new ConfigValidator();
            vi.mocked(validatorInstance.validateConfig).mockReturnValue({ valid: false, errors: ['Invalid field'] });

            // We need to ensure the loader uses our mocked validator
            // The constructor creates a new one, so we might need to inject it or mock the class
            vi.spyOn(loader.validator, 'validateConfig').mockReturnValue({ valid: false, errors: ['Mocked Error'] });

            await expect(loader.loadAiTwitterActivityConfig({})).rejects.toThrow('Configuration validation failed: Mocked Error');
        });

        it('should fallback to defaults when settings fail to load', async () => {
            vi.mocked(getSettings).mockRejectedValue(new Error('Load Failed'));

            const config = await loader.loadAiTwitterActivityConfig({});
            // Probability from defaults is 0.5 for replies
            expect(config.engagement.probabilities.reply).toBe(0.5);
        });

        it('should handle generic load errors', async () => {
            vi.mocked(config.getTwitterActivity).mockRejectedValue(new Error('Fatal Error'));
            await expect(loader.loadAiTwitterActivityConfig({})).rejects.toThrow('Configuration loading failed: Fatal Error');
        });
    });

    describe('Statistics and Cache Management', () => {
        it('should return correct stats', async () => {
            await loader.loadAiTwitterActivityConfig({ test: 1 });
            await loader.loadAiTwitterActivityConfig({ test: 1 }); // Hit

            const stats = loader.getStats();
            expect(stats.cache.hitCount).toBe(1);
            expect(stats.cache.loadCount).toBe(1);
            expect(stats.cache.hitRate).toBe('50.00%');
        });

        it('should return 0% hit rate when no loads', () => {
            const stats = loader.getStats();
            expect(stats.cache.hitRate).toBe('0%');
        });

        it('should clear cache', async () => {
            await loader.loadAiTwitterActivityConfig({ test: 1 });
            loader.clearCache();

            expect(loader.hitCount).toBe(0);
            expect(loader.loadCount).toBe(0);
        });
    });

    describe('Singleton and Convenience Exports', () => {
        it('should have a singleton instance', () => {
            expect(taskConfigLoader).toBeInstanceOf(TaskConfigLoader);
        });

        it('should work via convenience function', async () => {
            const config = await loadAiTwitterActivityConfig({});
            expect(config).toBeDefined();
        });
    });

    describe('buildConfig branches', () => {
        it('should use deep value defaults for probabilities', () => {
            const cfg = loader.buildConfig({
                settings: { twitter: {} }, // Missing reply nested object
                activityConfig: {},
                timingConfig: {},
                engagementLimits: {},
                humanizationConfig: {},
                payload: {}
            });
            expect(cfg.engagement.probabilities.reply).toBe(0.5);
        });

        it('should use system env for debug and performance', () => {
            process.env.DEBUG_MODE = 'true';
            process.env.PERFORMANCE_TRACKING = 'false';
            const cfg = loader.buildConfig({
                settings: {}, activityConfig: {}, timingConfig: {}, engagementLimits: {}, humanizationConfig: {}, payload: {}
            });
            expect(cfg.system.debugMode).toBe(true);
            expect(cfg.system.performanceTracking).toBe(false);
            delete process.env.DEBUG_MODE;
            delete process.env.PERFORMANCE_TRACKING;
        });

        it('should use payload for session timeout calculation', () => {
            const cfg = loader.buildConfig({
                settings: {},
                activityConfig: { defaultMinDuration: 10, defaultMaxDuration: 20 },
                timingConfig: {}, engagementLimits: {}, humanizationConfig: {},
                payload: { taskTimeoutMs: 5000 }
            });
            expect(cfg.session.timeout).toBe(5000);
        });
    });
});

/**
 * @fileoverview Unit tests for utils/mathUtils.js
 * Tests stochastic calculation utilities
 * @module tests/unit/mathUtils.test
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

describe('utils/mathUtils', () => {
    let mathUtils;

    beforeEach(async () => {
        vi.clearAllMocks();
        // Seed random for deterministic tests
        vi.spyOn(Math, 'random').mockReturnValue(0.5);
        
        const module = await import('../../utils/mathUtils.js');
        mathUtils = module.mathUtils;
    });

    afterEach(() => {
        vi.restoreAllMocks();
    });

    describe('gaussian', () => {
        it('should generate number around mean', () => {
            const result = mathUtils.gaussian(100, 10);
            
            expect(typeof result).toBe('number');
            // With random mocked at 0.5, we can predict the range
            expect(result).toBeGreaterThanOrEqual(0);
        });

        it('should respect min boundary', () => {
            const result = mathUtils.gaussian(50, 10, 80, 100);
            
            expect(result).toBeGreaterThanOrEqual(80);
        });

        it('should respect max boundary', () => {
            const result = mathUtils.gaussian(50, 10, 10, 20);
            
            expect(result).toBeLessThanOrEqual(20);
        });

        it('should respect both min and max boundaries', () => {
            const result = mathUtils.gaussian(100, 10, 50, 60);
            
            expect(result).toBeGreaterThanOrEqual(50);
            expect(result).toBeLessThanOrEqual(60);
        });
    });

    describe('randomInRange', () => {
        it('should return number within range', () => {
            const result = mathUtils.randomInRange(10, 20);
            
            expect(result).toBeGreaterThanOrEqual(10);
            expect(result).toBeLessThanOrEqual(20);
        });

        it('should handle same min and max', () => {
            const result = mathUtils.randomInRange(5, 5);
            
            expect(result).toBe(5);
        });

        it('should handle negative ranges', () => {
            const result = mathUtils.randomInRange(-10, -1);
            
            expect(result).toBeGreaterThanOrEqual(-10);
            expect(result).toBeLessThanOrEqual(-1);
        });
    });

    describe('roll', () => {
        it('should return true when threshold is 1', () => {
            const result = mathUtils.roll(1);
            
            expect(result).toBe(true);
        });

        it('should return false when threshold is 0', () => {
            const result = mathUtils.roll(0);
            
            expect(result).toBe(false);
        });

        it('should return true when random equals threshold', () => {
            const result = mathUtils.roll(0.5);
            
            // With random mocked at 0.5, roll(0.5) returns true (not less than)
            expect(typeof result).toBe('boolean');
        });
    });

    describe('sample', () => {
        it('should return random element from array', () => {
            const array = ['a', 'b', 'c', 'd', 'e'];
            const result = mathUtils.sample(array);
            
            expect(array).toContain(result);
        });

        it('should return null for empty array', () => {
            const result = mathUtils.sample([]);
            
            expect(result).toBeNull();
        });

        it('should return null for null input', () => {
            const result = mathUtils.sample(null);
            
            expect(result).toBeNull();
        });

        it('should return null for undefined input', () => {
            const result = mathUtils.sample(undefined);
            
            expect(result).toBeNull();
        });

        it('should return single element for single-item array', () => {
            const result = mathUtils.sample(['only']);
            
            expect(result).toBe('only');
        });
    });

    describe('Edge Cases', () => {
        it('should handle gaussian with no boundaries', () => {
            const result = mathUtils.gaussian(100, 15);
            
            expect(typeof result).toBe('number');
        });

        it('should handle randomInRange with large numbers', () => {
            const result = mathUtils.randomInRange(1000000, 9999999);
            
            expect(result).toBeGreaterThanOrEqual(1000000);
            expect(result).toBeLessThanOrEqual(9999999);
        });

        it('should handle sample with objects', () => {
            const objects = [{id: 1}, {id: 2}, {id: 3}];
            const result = mathUtils.sample(objects);
            
            expect(objects).toContain(result);
        });
    });
});

/**
 * @fileoverview Unit tests for AsyncQueue
 * @module tests/unit/async-queue.test
 */

import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { AsyncQueue, DiveQueue } from '../../utils/async-queue.js';
import { TWITTER_TIMEOUTS } from '../../constants/twitter-timeouts.js';

describe('AsyncQueue', () => {
  let queue;

  beforeEach(() => {
    queue = new AsyncQueue({
      maxConcurrent: 2,
      maxQueueSize: 5,
      defaultTimeout: 100
    });
  });

  afterEach(() => {
    queue.clear();
  });

  describe('Initialization', () => {
    it('should initialize with correct values', () => {
      expect(queue.maxConcurrent).toBe(2);
      expect(queue.maxQueueSize).toBe(5);
      expect(queue.defaultTimeout).toBe(100);
    });

    it('should use default values when not provided', () => {
      const defaultQueue = new AsyncQueue();
      expect(defaultQueue.maxConcurrent).toBe(3);
      expect(defaultQueue.maxQueueSize).toBe(50);
      expect(defaultQueue.defaultTimeout).toBe(TWITTER_TIMEOUTS.QUEUE_ITEM_TIMEOUT);
    });
  });

  describe('Task Addition & Processing', () => {
    it('should execute tasks concurrently', async () => {
      const startTimes = [];
      const task = async () => {
        startTimes.push(Date.now());
        await new Promise(r => setTimeout(r, 50));
        return 'ok';
      };

      const p1 = queue.add(task);
      const p2 = queue.add(task);

      await Promise.all([p1, p2]);

      // They should start almost at the same time
      expect(Math.abs(startTimes[0] - startTimes[1])).toBeLessThan(30);
    });

    it('should respect maxQueueSize', async () => {
      const neverEndingTask = () => new Promise(() => { });
      // 2 active slots + 5 queue slots = 7 total capacity
      for (let i = 0; i < 7; i++) {
        queue.add(neverEndingTask);
      }

      const result = await queue.add(async () => 'too late');
      expect(result.success).toBe(false);
      expect(result.reason).toBe('queue_full');
    });

    it('should process tasks in priority order', async () => {
      queue.maxConcurrent = 1;
      const executionOrder = [];

      const p1 = queue.add(async () => {
        await new Promise(r => setTimeout(r, 50));
        executionOrder.push('first');
      });

      const p2 = queue.add(async () => {
        executionOrder.push('low');
      }, { priority: 1 });
      const p3 = queue.add(async () => {
        executionOrder.push('high');
      }, { priority: 10 });

      await Promise.all([p1, p2, p3]);
      expect(executionOrder).toEqual(['first', 'high', 'low']);
    });

    it('should handle task errors', async () => {
      const result = await queue.add(async () => { throw new Error('fail'); });
      expect(result.success).toBe(false);
      expect(result.reason).toBe('error');
      expect(result.error).toBe('fail');
      expect(queue.failedCount).toBe(1);
    });

    it('should handle task timeouts', async () => {
      const result = await queue.add(() => new Promise(r => setTimeout(r, 500)), { timeout: 20 });
      expect(result.success).toBe(false);
      expect(result.reason).toBe('timeout');
      expect(queue.timedOutCount).toBe(1);
    });
  });

  describe('Statistics & Health', () => {
    it('should track average processing time', async () => {
      await queue.add(async () => { await new Promise(r => setTimeout(r, 20)); });
      await queue.add(async () => { await new Promise(r => setTimeout(r, 40)); });

      const stats = queue.getStats();
      expect(stats.averageProcessingTime).toBeGreaterThan(15);
      expect(stats.averageProcessingTime).toBeLessThan(70);
    });

    it('should report health correctly', () => {
      expect(queue.isHealthy()).toBe(true);
      queue.failedCount = 6;
      expect(queue.isHealthy()).toBe(false);

      queue.failedCount = 0;
      queue.timedOutCount = 11;
      expect(queue.getHealth().healthy).toBe(false);
    });

    it('should return complete status', () => {
      const status = queue.getStatus();
      expect(status).toHaveProperty('isProcessing');
      expect(status.queueLength).toBe(0);
    });
  });

  describe('Queue Management', () => {
    it('should clear the queue', () => {
      queue.maxConcurrent = 0;
      queue.add(() => Promise.resolve());
      queue.add(() => Promise.resolve());

      expect(queue.queue.length).toBe(2);
      const result = queue.clear();
      expect(result.dropped).toBe(2);
      expect(queue.queue.length).toBe(0);
    });
  });
});

describe('DiveQueue', () => {
  let diveQueue;

  beforeEach(() => {
    diveQueue = new DiveQueue({
      maxQueueSize: 10,
      defaultTimeout: 1000,
      replies: 2,
      fallbackEngagement: true
    });
  });

  describe('Initialization', () => {
    it('should enforce maxConcurrent 1', () => {
      expect(diveQueue.maxConcurrent).toBe(1);
    });

    it('should clamp timeouts', () => {
      const dq1 = new DiveQueue({ defaultTimeout: 0 });
      expect(dq1.defaultTimeout).toBe(10000);

      const dq2 = new DiveQueue({ defaultTimeout: 999999 });
      expect(dq2.defaultTimeout).toBe(300000);
    });
  });

  describe('Engagement Tracking', () => {
    it('should record valid engagement', () => {
      expect(diveQueue.recordEngagement('replies')).toBe(true);
      expect(diveQueue.recordEngagement('replies')).toBe(true);
      expect(diveQueue.recordEngagement('replies')).toBe(false);
    });

    it('should return engagement progress', () => {
      diveQueue.recordEngagement('likes');
      const progress = diveQueue.getEngagementProgress();
      expect(progress.likes.current).toBe(1);
      expect(progress.likes.remaining).toBe(4);
    });

    it('should reset engagement', () => {
      diveQueue.recordEngagement('likes');
      diveQueue.resetEngagement();
      expect(diveQueue.engagementCounters.likes).toBe(0);
    });

    it('should update limits at runtime', () => {
      diveQueue.updateEngagementLimits({ likes: 100 });
      expect(diveQueue.engagementLimits.likes).toBe(100);
    });

    it('should return false for unknown action', () => {
      expect(diveQueue.recordEngagement('unknown')).toBe(false);
    });
  });

  describe('addDive', () => {
    it('should execute primary dive function', async () => {
      const result = await diveQueue.addDive(async () => 'ok');
      expect(result.success).toBe(true);
      expect(result.result).toBe('ok');
    });

    it('should use fallback if primary fails', async () => {
      const result = await diveQueue.addDive(async () => { throw new Error('fail'); }, async () => 'fb');
      expect(result.success).toBe(true);
      expect(result.result.fallbackUsed).toBe(true);
      expect(result.result.fallbackResult).toBe('fb');
    });

    it('should handle both failing', async () => {
      const result = await diveQueue.addDive(async () => { throw new Error('p'); }, async () => { throw new Error('f'); });
      expect(result.success).toBe(false);
      expect(result.error).toContain('p');
      expect(result.error).toContain('f');
    });

    it('should handle dive timeouts', async () => {
      const slowDive = () => new Promise(r => setTimeout(r, 500));
      const result = await diveQueue.addDive(slowDive, null, { timeout: 30 });
      expect(result.success).toBe(false);
      // In the streamlined version, addDive can return 'timeout' from the base class
      expect(result.reason || result.error).toBe('timeout');
    });
  });

  describe('Quick Mode & Status', () => {
    it('should toggle quick mode', () => {
      diveQueue.enableQuickMode();
      expect(diveQueue.quickMode).toBe(true);
      diveQueue.disableQuickMode();
      expect(diveQueue.quickMode).toBe(false);
    });

    it('should return full status', () => {
      const status = diveQueue.getFullStatus();
      expect(status).toHaveProperty('engagement');
      expect(status).toHaveProperty('quickMode');
    });
  });
});

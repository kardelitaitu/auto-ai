/**
 * Async Queue Manager for AI Operations
 * Handles race conditions and provides timeout/fallback mechanisms
 * @module utils/async-queue
 */

import { createLogger } from './logger.js';
import { TWITTER_TIMEOUTS } from '../constants/twitter-timeouts.js';

const logger = createLogger('async-queue.js');

export class AsyncQueue {
    constructor(options = {}) {
        this.maxConcurrent = options.maxConcurrent ?? 3;
        this.maxQueueSize = options.maxQueueSize ?? 50;
        this.defaultTimeout = options.defaultTimeout ?? TWITTER_TIMEOUTS.QUEUE_ITEM_TIMEOUT;

        this.queue = [];
        this.active = new Map();
        this.processingPromise = null; // Use promise chain instead of boolean flag
        this.processing = false; // Boolean flag for getStatus() compatibility
        this.processedCount = 0;
        this.failedCount = 0;
        this.timedOutCount = 0;

        this.stats = {
            totalAdded: 0,
            totalCompleted: 0,
            totalFailed: 0,
            totalTimedOut: 0,
            averageWaitTime: 0,
            averageProcessingTime: 0
        };

        logger.info(`[AsyncQueue] Initialized (maxConcurrent: ${this.maxConcurrent}, maxQueueSize: ${this.maxQueueSize}, defaultTimeout: ${this.defaultTimeout}ms)`);
    }

    /**
     * Add a task to the queue
     * @param {Function} taskFn - Async function to execute
     * @param {object} options - Task options
     * @returns {Promise} Result of the task
     */
    async add(taskFn, options = {}) {
        const id = `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const timeout = options.timeout ?? this.defaultTimeout;
        const priority = options.priority ?? 0;
        const taskName = options.name || 'unnamed';

        // Check queue size with atomic access
        const currentQueueSize = this.queue.length + this.active.size;
        if (currentQueueSize >= this.maxQueueSize) {
            logger.warn(`[AsyncQueue] Queue full, rejecting task: ${taskName} (current: ${currentQueueSize}, max: ${this.maxQueueSize})`);
            return { success: false, reason: 'queue_full', taskName: id };
        }

        // Create promise that will be resolved/rejected when task completes
        const taskPromise = new Promise((resolve, reject) => {
            const startTime = Date.now();
            this.queue.push({
                id,
                taskFn,
                timeout,  // Ensure timeout is properly stored
                priority,
                taskName,
                resolve,
                reject,
                enqueueTime: startTime
            });
            this.stats.totalAdded++;

            // Trigger queue processing with promise chaining
            this._processQueue().catch(err => {
                logger.error(`[AsyncQueue] Queue processing error: ${err.message}`);
            });
        });

        return taskPromise;
    }

    /**
     * Process items in the queue
     * Ensures we stay within concurrency limits
     */
    async _processQueue() {
        if (this.queue.length === 0 || this.active.size >= this.maxConcurrent) {
            return;
        }

        // Sort by priority (higher priority first)
        this.queue.sort((a, b) => b.priority - a.priority);

        while (this.queue.length > 0 && this.active.size < this.maxConcurrent) {
            const item = this.queue.shift();
            this._runTask(item);
        }
    }

    /**
     * Run a single task and manage its lifecycle
     * @param {object} item - Queue item
     */
    async _runTask(item) {
        const startTime = Date.now();
        this.active.set(item.id, { ...item, startTime });
        this.processing = true;

        logger.debug(`[AsyncQueue] Starting task: ${item.taskName} (active: ${this.active.size}/${this.maxConcurrent})`);

        let timeoutId;
        const timeoutPromise = new Promise((_, reject) => {
            timeoutId = setTimeout(() => {
                reject(new Error('timeout'));
            }, item.timeout);
        });

        try {
            const result = await Promise.race([
                item.taskFn(),
                timeoutPromise
            ]);

            const processingTime = Date.now() - startTime;
            this.stats.totalCompleted++;
            this._updateAverageStats('processing', processingTime);

            logger.info(`[AsyncQueue] ✓ Completed task: ${item.taskName} in ${processingTime}ms`);
            item.resolve({ success: true, result, taskName: item.taskName, processingTime });

        } catch (error) {
            const isTimeout = error.message === 'timeout';
            const processingTime = Date.now() - startTime;

            if (isTimeout) {
                this.stats.totalTimedOut++;
                this.timedOutCount++;
                logger.warn(`[AsyncQueue] ⚠ Task timed out: ${item.taskName} after ${processingTime}ms`);
            } else {
                this.stats.totalFailed++;
                this.failedCount++;
                logger.error(`[AsyncQueue] ✗ Task failed: ${item.taskName} - ${error.message}`);
            }

            item.resolve({
                success: false,
                reason: isTimeout ? 'timeout' : 'error',
                error: error.message,
                taskName: item.taskName,
                processingTime
            });
        } finally {
            clearTimeout(timeoutId);
            this.active.delete(item.id);
            this.processedCount++;

            // Check if queue has more items to process
            this._processQueue().catch(err => {
                logger.error(`[AsyncQueue] Post-task queue processing error: ${err.message}`);
            });

            // Update processing flag if everything is done
            if (this.active.size === 0 && this.queue.length === 0) {
                this.processing = false;
            }
        }
    }


    /**
     * Update average statistics
     */
    _updateAverageStats(type, value) {
        const count = this.stats.totalCompleted + this.stats.totalFailed;
        if (count <= 1) {
            if (type === 'processing') {
                this.stats.averageProcessingTime = value;
            }
            return;
        }

        if (type === 'processing') {
            const total = this.stats.averageProcessingTime * (count - 1) + value;
            this.stats.averageProcessingTime = total / count;
        }
    }

    /**
     * Get queue status
     */
    getStatus() {
        return {
            queueLength: this.queue.length,
            activeCount: this.active.size,
            maxConcurrent: this.maxConcurrent,
            isProcessing: this.processing,
            processed: this.processedCount,
            failed: this.failedCount,
            timedOut: this.timedOutCount
        };
    }

    /**
     * Get detailed statistics
     */
    getStats() {
        return {
            ...this.stats,
            queueStatus: this.getStatus(),
            utilizationPercent: this.active.size > 0
                ? Math.round((this.active.size / this.maxConcurrent) * 100)
                : 0
        };
    }

    /**
     * Clear the queue
     */
    clear() {
        const dropped = this.queue.length;
        this.queue = [];

        logger.info(`[AsyncQueue] Cleared queue (dropped ${dropped} tasks)`);

        return { dropped };
    }

    /**
     * Check if queue is healthy
     */
    isHealthy() {
        return this.failedCount < 5 && this.timedOutCount < 10;
    }

    /**
     * Alias for isHealthy() for external API compatibility
     */
    isQueueHealthy() {
        return this.isHealthy();
    }

    /**
     * Get health status
     */
    getHealth() {
        return {
            healthy: this.isHealthy(),
            failedCount: this.failedCount,
            timedOutCount: this.timedOutCount,
            queueLength: this.queue.length
        };
    }
}

/**
 * Dive Queue - Specialized queue for tweet dive operations
 * Extends AsyncQueue with dive-specific features
 */
export class DiveQueue extends AsyncQueue {
    constructor(options = {}) {
        // Use passed timeout or default, but ensure it's reasonable
        const timeout = options.defaultTimeout ?? TWITTER_TIMEOUTS.DIVE_TIMEOUT;
        const finalTimeout = Math.max(10000, Math.min(timeout, 300000)); // Clamp between 10s and 5min

        super({
            maxConcurrent: 1,  // Force sequential processing - only 1 dive at a time
            maxQueueSize: options.maxQueueSize ?? 30,
            defaultTimeout: finalTimeout
        });

        this.fallbackEngagement = options.fallbackEngagement ?? false;
        this.quickMode = false;

        // Engagement tracking
        this.engagementLimits = {
            replies: options.replies ?? 3,
            retweets: options.retweets ?? 1,
            quotes: options.quotes ?? 1,
            likes: options.likes ?? 5,
            follows: options.follows ?? 2,
            bookmarks: options.bookmarks ?? 2
        };

        this.engagementCounters = {
            replies: 0,
            retweets: 0,
            quotes: 0,
            likes: 0,
            follows: 0,
            bookmarks: 0
        };

        logger.info(`[DiveQueue] Initialized with engagement limits: ${JSON.stringify(this.engagementLimits)}`);
    }

    /**
     * Check if engagement limit allows action (synchronous - optimized for performance)
     */
    canEngage(action) {
        const limit = this.engagementLimits[action] ?? Infinity;
        const current = this.engagementCounters[action] ?? 0;
        return current < limit;
    }

    /**
     * Record engagement action (synchronous - optimized for performance)
     */
    recordEngagement(action) {
        if (this.engagementCounters.hasOwnProperty(action)) {
            const limit = this.engagementLimits[action] ?? Infinity;
            const current = this.engagementCounters[action];

            if (current < limit) {
                this.engagementCounters[action]++;
                logger.debug(`[DiveQueue] ✓ Engagement recorded: ${action} (${current + 1}/${limit})`);
                return true;
            } else {
                logger.debug(`[DiveQueue] ⚠ Engagement limit reached: ${action} (${current}/${limit})`);
                return false;
            }
        }
        return false;
    }

    /**
     * Get engagement progress (synchronous - optimized for performance)
     */
    getEngagementProgress() {
        const progress = {};
        for (const action of Object.keys(this.engagementLimits)) {
            progress[action] = {
                current: this.engagementCounters[action],
                limit: this.engagementLimits[action],
                remaining: Math.max(0, this.engagementLimits[action] - this.engagementCounters[action]),
                percentUsed: Math.round((this.engagementCounters[action] / this.engagementLimits[action]) * 100)
            };
        }
        return progress;
    }

    /**
     * Update engagement limits at runtime
     */
    updateEngagementLimits(newLimits) {
        this.engagementLimits = { ...this.engagementLimits, ...newLimits };
        logger.info(`[DiveQueue] Updated engagement limits: ${JSON.stringify(this.engagementLimits)}`);
    }

    /**
      * Add dive task with fallback support
      */
    async addDive(diveFn, fallbackFn, options = {}) {
        const taskName = options.taskName || `dive_${Date.now()}`;
        const timeout = options.timeout ?? this.defaultTimeout;

        logger.debug(`[DiveQueue] addDive called: ${taskName}, timeout: ${timeout}ms`);

        return this.add(async () => {
            try {
                logger.debug(`[DiveQueue] Running primary dive function: ${taskName}`);
                return await diveFn();
            } catch (error) {
                const isTimeout = error.message === 'timeout' || error.message === 'dive_timeout';
                logger.warn(`[DiveQueue] Primary dive failed (${error.message}), checking fallback...`);

                if (this.fallbackEngagement && fallbackFn) {
                    try {
                        logger.debug(`[DiveQueue] Running fallback function: ${taskName}`);
                        const fallbackResult = await fallbackFn();

                        // We return an object indicating fallback was used
                        // AsyncQueue will wrap this as the 'result'
                        return {
                            fallbackUsed: true,
                            fallbackResult
                        };
                    } catch (fbError) {
                        logger.error(`[DiveQueue] Fallback also failed: ${fbError.message}`);
                        throw new Error(`${isTimeout ? 'dive_timeout' : error.message}; fallback: ${fbError.message}`);
                    }
                }

                // No fallback or disabled, propagate error with custom message
                if (isTimeout) throw new Error('dive_timeout');
                throw error;
            }
        }, {
            ...options,
            name: taskName,
            timeout: timeout
        });
    }

    /**
      * Enable quick mode (reduced timeouts for faster fallback)
      */
    enableQuickMode() {
        this.quickMode = true;
        this.defaultTimeout = 15000;  // Still faster than normal 20-30s, but enough for AI
        logger.info(`[DiveQueue] Quick mode enabled (timeout: ${this.defaultTimeout}ms)`);
    }

    /**
      * Disable quick mode
      */
    disableQuickMode() {
        this.quickMode = false;
        this.defaultTimeout = 20000;  // Normal timeout
        logger.info(`[DiveQueue] Quick mode disabled (timeout: ${this.defaultTimeout}ms)`);
    }

    /**
     * Get comprehensive queue status including engagement
     */
    getFullStatus() {
        return {
            queue: this.getStatus(),
            engagement: this.getEngagementProgress(),
            quickMode: this.quickMode,
            health: this.getHealth()
        };
    }

    /**
     * Reset engagement counters
     */
    resetEngagement() {
        for (const key of Object.keys(this.engagementCounters)) {
            this.engagementCounters[key] = 0;
        }
        logger.info(`[DiveQueue] Engagement counters reset`);
    }

    /**
     * Update engagement limits at runtime
     */
    updateEngagementLimits(newLimits) {
        this.engagementLimits = { ...this.engagementLimits, ...newLimits };
        logger.info(`[DiveQueue] Updated engagement limits: ${JSON.stringify(this.engagementLimits)}`);
    }
}

export default AsyncQueue;

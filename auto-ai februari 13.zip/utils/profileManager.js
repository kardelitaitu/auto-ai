import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load profiles safely from ../data/ relative to utils/
const profilesPath = path.join(__dirname, '../data/twitterActivityProfiles.json');
const generatorPath = path.join(__dirname, 'generateProfiles.js');
let PROFILES = [];
let loadingPromise = null; // Track async loading state to prevent race conditions

/**
 * Loads profiles from the JSON file
 * @returns {boolean} True if profiles were loaded successfully
 */
function loadProfiles() {
    try {
        // Use synchronous check + read for initial load (fast path)
        if (fs.existsSync(profilesPath)) {
            const data = fs.readFileSync(profilesPath, 'utf8');
            PROFILES = JSON.parse(data);
            return PROFILES.length > 0;
        }
        PROFILES = []; // Clear if missing
        return false;
    } catch (e) {
        console.error("[profileManager.js] Failed to load profiles", e);
        PROFILES = []; // Clear on error
        return false;
    }
}

/**
 * Runs the profile generator script asynchronously (non-blocking)
 * @returns {Promise<boolean>} True if generation was successful
 */
async function generateProfilesAsync() {
    try {
        console.log('[profileManager.js] No profiles found. Auto-generating...');

        // Use async exec instead of blocking execSync
        await execAsync(`node "${generatorPath}"`, {
            cwd: path.join(__dirname, '..')
        });

        console.log('[profileManager.js] Profile generation complete.');
        return true;
    } catch (e) {
        console.error('[profileManager.js] Failed to generate profiles:', e.message);
        return false;
    }
}

/**
 * Ensures profiles are loaded, generating them if necessary
 * Uses promise-based approach to prevent race conditions
 * @returns {Promise<boolean>} True if profiles are available
 */
async function ensureProfilesLoadedAsync() {
    if (PROFILES.length > 0) return true;

    // If already loading, wait for that to complete
    if (loadingPromise) {
        return loadingPromise;
    }

    // Create loading promise to prevent race conditions
    loadingPromise = (async () => {
        try {
            // Try loading first
            if (loadProfiles()) return true;

            // If loading failed, try generating asynchronously
            if (await generateProfilesAsync()) {
                // Retry loading after generation
                return loadProfiles();
            }

            return false;
        } finally {
            loadingPromise = null;
        }
    })();

    return loadingPromise;
}

/**
 * Synchronous check - for backward compatibility
 * @returns {boolean} True if profiles are already loaded
 */
function ensureProfilesLoaded() {
    if (PROFILES.length > 0) return true;
    return loadProfiles();
}

// Profile validation schema
const PROFILE_REQUIRED_FIELDS = ['id', 'type', 'timings', 'probabilities'];
const PROFILE_OPTIONAL_FIELDS = ['inputMethod', 'inputMethodPct', 'theme', 'inputDelay'];

/**
 * Validate a single profile object
 * @param {object} profile - Profile to validate
 * @returns {object} Validation result with valid flag and errors
 */
function validateProfile(profile) {
    const errors = [];

    if (!profile || typeof profile !== 'object') {
        return { valid: false, errors: ['Profile must be an object'] };
    }

    // Check required fields
    for (const field of PROFILE_REQUIRED_FIELDS) {
        if (!(field in profile)) {
            errors.push(`Missing required field: ${field}`);
        }
    }

    // Validate timings structure if present
    if (profile.timings) {
        if (!profile.timings.scrollPause || typeof profile.timings.scrollPause.mean !== 'number') {
            errors.push('Invalid timings.scrollPause.mean: must be a number');
        }
    }

    // Validate probabilities structure if present
    if (profile.probabilities) {
        const probFields = ['dive', 'like', 'follow', 'retweet', 'quote'];
        for (const field of probFields) {
            if (profile.probabilities[field] !== undefined) {
                const val = profile.probabilities[field];
                if (typeof val !== 'number' || val < 0 || val > 100) {
                    errors.push(`Invalid probabilities.${field}: must be 0-100`);
                }
            }
        }
    }

    return {
        valid: errors.length === 0,
        errors
    };
}

/**
 * Validate all loaded profiles
 * @returns {object} Validation result with valid flag and profile errors
 */
function validateAllProfiles() {
    const results = {
        valid: true,
        total: PROFILES.length,
        validCount: 0,
        invalidCount: 0,
        errors: []
    };

    for (let i = 0; i < PROFILES.length; i++) {
        const profile = PROFILES[i];
        const validation = validateProfile(profile);

        if (!validation.valid) {
            results.valid = false;
            results.invalidCount++;
            results.errors.push({
                profileIndex: i,
                profileId: profile?.id || 'unknown',
                errors: validation.errors
            });
        } else {
            results.validCount++;
        }
    }

    return results;
}

/**
 * Log validation issues to console
 * @param {object} validation - Validation results from validateAllProfiles
 */
function logValidationIssues(validation) {
    if (!validation.valid) {
        console.warn(`[profileManager.js] Profile validation issues: ${validation.invalidCount}/${validation.total} invalid`);
        for (const err of validation.errors.slice(0, 3)) {
            console.warn(`  - Profile "${err.profileId}": ${err.errors.join(', ')}`);
        }
    }
}

// Initial load attempt (synchronous for fast startup)
loadProfiles();
if (PROFILES.length === 0) {
    console.warn("[profileManager.js] Profiles not found. Will auto-generate on first use.");
} else {
    // Validate loaded profiles on startup (warn only, don't fail)
    logValidationIssues(validateAllProfiles());
}

export const profileManager = {
    /**
     * Get a starter profile (synchronous - for backward compatibility)
     * @returns {object} A random profile
     */
    getStarter: () => {
        if (!ensureProfilesLoaded()) {
            throw new Error("[profileManager.js] No profiles loaded and auto-generation failed. Please run utils/generateProfiles.js manually.");
        }

        const fast = PROFILES.filter(p => p.timings?.scrollPause?.mean < 2500);
        const pool = fast.length > 0 ? fast : PROFILES;

        return pool[Math.floor(Math.random() * pool.length)];
    },

    /**
     * Get a starter profile (async version - preferred for new code)
     * @returns {Promise<object>} A random profile
     */
    getStarterAsync: async () => {
        const loaded = await ensureProfilesLoadedAsync();
        if (!loaded) {
            throw new Error("[profileManager.js] No profiles loaded and auto-generation failed. Please run utils/generateProfiles.js manually.");
        }

        const fast = PROFILES.filter(p => p.timings?.scrollPause?.mean < 2500);
        const pool = fast.length > 0 ? fast : PROFILES;

        return pool[Math.floor(Math.random() * pool.length)];
    },

    /**
     * Get a fatigued variant profile (synchronous)
     * @param {number} currentMean - Current scroll pause mean
     * @returns {object|null} A fatigued variant or null
     */
    getFatiguedVariant: (currentMean) => {
        if (!ensureProfilesLoaded()) {
            return null; // Graceful degradation for fatigue variant
        }

        const candidates = PROFILES.filter(p => p.timings?.scrollPause?.mean > (currentMean * 1.4));
        if (candidates.length === 0) return null;
        return candidates[Math.floor(Math.random() * candidates.length)];
    },

    /**
     * Get profile by ID (synchronous)
     * @param {string} profileId - Profile ID to find
     * @returns {object} The profile object
     */
    getById: (profileId) => {
        if (!ensureProfilesLoaded()) {
            throw new Error("[profileManager.js] No profiles loaded and auto-generation failed. Please run utils/generateProfiles.js manually.");
        }

        const profile = PROFILES.find(p => p.id === profileId);

        if (!profile) {
            const availableIds = PROFILES.map(p => p.id).join(', ');
            throw new Error(
                `[profileManager.js] Profile "${profileId}" not found. Available profiles: ${availableIds}`
            );
        }

        return profile;
    },

    /**
     * Get profile by ID (async version)
     * @param {string} profileId - Profile ID to find
     * @returns {Promise<object>} The profile object
     */
    getByIdAsync: async (profileId) => {
        const loaded = await ensureProfilesLoadedAsync();
        if (!loaded) {
            throw new Error("[profileManager.js] No profiles loaded and auto-generation failed. Please run utils/generateProfiles.js manually.");
        }

        const profile = PROFILES.find(p => p.id === profileId);

        if (!profile) {
            const availableIds = PROFILES.map(p => p.id).join(', ');
            throw new Error(
                `[profileManager.js] Profile "${profileId}" not found. Available profiles: ${availableIds}`
            );
        }

        return profile;
    },

    /**
     * Manually reload profiles from disk
     * @returns {boolean} True if reload was successful
     */
    reload: () => {
        const loaded = loadProfiles();
        if (loaded) logValidationIssues(validateAllProfiles());
        return loaded;
    },

    /**
     * Manually reload profiles from disk (async)
     * @returns {Promise<boolean>} True if reload was successful
     */
    reloadAsync: async () => {
        const loaded = await ensureProfilesLoadedAsync();
        if (loaded) logValidationIssues(validateAllProfiles());
        return loaded;
    },

    /**
     * Get count of loaded profiles
     * @returns {number} Number of profiles currently loaded
     */
    getCount: () => {
        return PROFILES.length;
    }
};

/**
 * @fileoverview Circuit Breaker for Model Health Monitoring
 * @module core/circuit-breaker
 */

import { createLogger } from '../utils/logger.js';

const logger = createLogger('circuit-breaker.js');

const STATE_CLOSED = 'CLOSED';
const STATE_OPEN = 'OPEN';
const STATE_HALF_OPEN = 'HALF_OPEN';

/**
 * @class CircuitBreaker
 * @description Prevents cascading failures by monitoring model health and tripping when failure threshold reached
 */
class CircuitBreaker {
    constructor(options = {}) {
        this.failureThreshold = options.failureThreshold || 50; // default 50%
        this.successThreshold = options.successThreshold || 2;
        this.halfOpenTime = options.halfOpenTime || 30000;
        this.monitoringWindow = options.monitoringWindow || 60000;
        this.minSamples = options.minSamples || 5;

        this.breakers = new Map();
    }

    /**
     * Get or create a circuit breaker for a model
     * @param {string} modelId - Unique model identifier
     * @returns {object} Circuit breaker instance
     */
    getBreaker(modelId) {
        if (!this.breakers.has(modelId)) {
            this.breakers.set(modelId, this._createBreaker());
        }
        return this.breakers.get(modelId);
    }

    /**
     * Create a new breaker instance
     * @private
     */
    _createBreaker() {
        return {
            state: STATE_CLOSED,
            failures: 0,
            successes: 0,
            lastFailure: null,
            lastSuccess: null,
            nextAttempt: null,
            history: []
        };
    }

    /**
     * Execute a function through the circuit breaker
     * @param {string} modelId - Model identifier
     * @param {Function} fn - Async function to execute
     * @param {object} options - Execution options
     * @returns {Promise<any>} Function result
     */
    async execute(modelId, fn, options = {}) {
        const breaker = this.getBreaker(modelId);

        if (breaker.state === STATE_OPEN) {
            if (Date.now() >= breaker.nextAttempt) {
                breaker.state = STATE_HALF_OPEN;
                breaker.successes = 0;
                logger.info(`[CircuitBreaker][${modelId}] Transitioning to HALF_OPEN`);
            } else {
                const waitTime = breaker.nextAttempt - Date.now();
                const error = new Error(`Circuit breaker OPEN for ${modelId}. Retry after ${Math.ceil(waitTime / 1000)}s`);
                error.code = 'CIRCUIT_OPEN';
                error.modelId = modelId;
                error.retryAfter = waitTime;

                throw error;
            }
        }

        const startTime = Date.now();
        try {
            const result = await fn();
            this._recordSuccess(breaker, modelId, Date.now() - startTime);
            return result;
        } catch (error) {
            this._recordFailure(breaker, modelId, error, Date.now() - startTime);
            throw error;
        }
    }

    /**
     * Check if circuit is open
     * @private
     */
    _isOpen(breaker) {
        if (breaker.state === STATE_OPEN) {
            if (Date.now() >= breaker.nextAttempt) {
                return false;
            }
            return true;
        }
        return false;
    }

    /**
     * Record successful execution
     * @private
     */
    _recordSuccess(breaker, modelId, duration) {
        breaker.successes++;
        breaker.lastSuccess = Date.now();
        breaker.history.push({
            time: Date.now(),
            type: 'success',
            duration
        });
        this._cleanupHistory(breaker);

        if (breaker.state === STATE_HALF_OPEN) {
            if (breaker.successes >= this.successThreshold) {
                breaker.state = STATE_CLOSED;
                breaker.failures = 0;
                breaker.successes = 0;
                logger.info(`[CircuitBreaker][${modelId}] CLOSED (recovered)`);
            }
        }
    }

    /**
     * Record failed execution
     * @private
     */
    _recordFailure(breaker, modelId, error, duration) {
        breaker.failures++;
        breaker.lastFailure = Date.now();
        breaker.history.push({
            time: Date.now(),
            type: 'failure',
            error: error.message,
            duration
        });
        this._cleanupHistory(breaker);

        const failureRate = this._calculateFailureRate(breaker);

        if (breaker.state === STATE_HALF_OPEN) {
            // Any failure in HALF_OPEN trips it back to OPEN immediately
            breaker.state = STATE_OPEN;
            breaker.nextAttempt = Date.now() + this.halfOpenTime;
            logger.warn(`[CircuitBreaker][${modelId}] OPEN (failed in HALF_OPEN)`);
        } else if (breaker.state === STATE_CLOSED && breaker.history.length >= this.minSamples && failureRate >= this.failureThreshold) {
            breaker.state = STATE_OPEN;
            breaker.nextAttempt = Date.now() + this.halfOpenTime;
            logger.warn(`[CircuitBreaker][${modelId}] OPEN (failure rate: ${failureRate.toFixed(1)}%)`);
        }
    }

    /**
     * Calculate failure rate percentage
     * @private
     */
    _calculateFailureRate(breaker) {
        const windowStart = Date.now() - this.monitoringWindow;
        const recentHistory = breaker.history.filter(h => h.time >= windowStart);

        if (recentHistory.length === 0) return 0;

        const failures = recentHistory.filter(h => h.type === 'failure').length;
        return (failures / recentHistory.length) * 100;
    }

    /**
     * Clean up old history entries
     * @private
     */
    _cleanupHistory(breaker) {
        const windowStart = Date.now() - this.monitoringWindow;
        breaker.history = breaker.history.filter(h => h.time >= windowStart);

        if (breaker.history.length > 100) {
            breaker.history = breaker.history.slice(-100);
        }
    }

    /**
     * Get health status of a model
     * @param {string} modelId - Model identifier
     * @returns {object}
     */
    getHealth(modelId) {
        const breaker = this.breakers.get(modelId);

        if (!breaker) {
            return { status: 'unknown', modelId };
        }

        const failureRate = this._calculateFailureRate(breaker);
        const windowStart = Date.now() - this.monitoringWindow;
        const recentHistory = breaker.history.filter(h => h.time >= windowStart);
        const avgDuration = recentHistory.length > 0
            ? recentHistory.reduce((sum, h) => sum + (h.duration || 0), 0) / recentHistory.length
            : 0;

        return {
            status: breaker.state,
            modelId,
            failureRate: parseFloat(failureRate.toFixed(2)),
            successRate: parseFloat((100 - failureRate).toFixed(2)),
            recentOperations: recentHistory.length,
            lastSuccess: breaker.lastSuccess,
            lastFailure: breaker.lastFailure,
            avgDuration: Math.round(avgDuration),
            nextAttempt: breaker.nextAttempt
        };
    }

    /**
     * Get status of all breakers
     * @returns {object}
     */
    getAllStatus() {
        const status = {};

        for (const [modelId, breaker] of this.breakers.entries()) {
            const health = this.getHealth(modelId);
            status[modelId] = {
                state: breaker.state,
                failureRate: `${health.failureRate}%`,
                failures: breaker.failures,
                successes: breaker.successes,
                lastFailure: breaker.lastFailure,
                lastSuccess: breaker.lastSuccess
            };
        }

        return status;
    }

    /**
     * Reset a specific breaker
     * @param {string} modelId - Model identifier
     */
    reset(modelId) {
        this.breakers.set(modelId, this._createBreaker());
        logger.info(`[CircuitBreaker][${modelId}] Reset`);
    }

    /**
     * Reset all breakers
     */
    resetAll() {
        this.breakers.clear();
        logger.info('[CircuitBreaker] All breakers reset');
    }

    /**
     * Force open a breaker (for maintenance)
     * @param {string} modelId - Model identifier
     */
    forceOpen(modelId) {
        const breaker = this.getBreaker(modelId);
        breaker.state = STATE_OPEN;
        breaker.nextAttempt = Date.now() + (3600000 * 24); // 24 hours
        logger.warn(`[CircuitBreaker][${modelId}] Manually forced OPEN`);
    }

    /**
     * Force close a breaker (for recovery)
     * @param {string} modelId - Model identifier
     */
    forceClose(modelId) {
        const breaker = this.getBreaker(modelId);
        breaker.state = STATE_CLOSED;
        breaker.failures = 0;
        breaker.successes = 0;
        breaker.nextAttempt = null;
        logger.info(`[CircuitBreaker][${modelId}] Manually forced CLOSED`);
    }
}

export default CircuitBreaker;

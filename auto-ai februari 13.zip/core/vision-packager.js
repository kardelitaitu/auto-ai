/**
 * @fileoverview Vision Packager - Captures and compresses screenshots with ROI detection.
 * Part of the Distributed Agentic Orchestration (DAO) architecture.
 * @module core/vision-packager
 */

import { createLogger } from '../utils/logger.js';
import RoIDetector from './vision/roi-detector.js';
import ImageStorage from './vision/image-storage.js';

const logger = createLogger('vision-packager.js');

class VisionPackager {
    constructor(storageDir) {
        this.roiDetector = new RoIDetector();
        this.storage = new ImageStorage(storageDir);
        logger.info(`VisionPackager initialized.`);
    }

    async captureScreenshot(page, options = {}) {
        const { fullPage = false, clip = null, sessionId = 'unknown', saveToDisk = true } = options;

        try {
            const timestamp = Date.now();
            const safeSessionId = sessionId.replace(/:/g, '-');
            const filename = `${safeSessionId}_${timestamp}.jpg`;

            logger.debug(`[VisionPackager] Capturing screenshot: ${filename}`);

            const screenshotOptions = {
                type: 'jpeg',
                quality: 70,
                fullPage
            };

            if (clip) {
                screenshotOptions.clip = clip;
            }

            const buffer = await page.screenshot(screenshotOptions);

            const viewport = await page.evaluate(() => ({
                width: window.innerWidth,
                height: window.innerHeight
            }));

            logger.info(`[VisionPackager] 📐 Window: ${viewport.width}x${viewport.height}`);

            const base64 = buffer.toString('base64');
            let filepath = null;

            if (saveToDisk) {
                filepath = await this.storage.save(filename, buffer);
                logger.info(`[VisionPackager] Saved: ${filename} (${buffer.length} bytes)`);
            } else {
                logger.debug(`[VisionPackager] Verified memory capture (${buffer.length} bytes)`);
            }

            return {
                screenshotPath: filepath,
                screenshotBuffer: buffer,
                base64,
                roi: clip || { x: 0, y: 0, width: viewport.width, height: viewport.height },
                metadata: {
                    timestamp,
                    filename,
                    sizeBytes: buffer.length,
                    fullPage,
                    viewport,
                    url: page.url()
                }
            };

        } catch (error) {
            logger.error(`[VisionPackager] Capture failed:`, error.message);
            throw error;
        }
    }

    async captureWithROI(page, sessionId = 'unknown') {
        const roi = await this.roiDetector.detect(page);
        const options = {
            fullPage: false,
            sessionId,
            saveToDisk: false
        };

        if (roi) {
            logger.debug(`[VisionPackager] ROI detected: ${JSON.stringify(roi)}`);
            options.clip = roi;
        }

        return await this.captureScreenshot(page, options);
    }

    async cleanupOldScreenshots(maxAgeMs) {
        const count = await this.storage.cleanup(maxAgeMs);
        if (count > 0) {
            logger.info(`[VisionPackager] Cleaned up ${count} screenshots`);
        }
        return count;
    }

    async getStats() {
        return await this.storage.getStats();
    }
}

export default VisionPackager;

/**
 * @fileoverview Manages browser sessions, including their lifecycle, status, and persistence.
 * @module core/sessionManager
 */

import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { createLogger } from '../utils/logger.js';
import { getTimeoutValue, getSettings } from '../utils/configLoader.js';
import metricsCollector from '../utils/metrics.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SESSION_STATE_FILE = path.join(__dirname, '../data/sessionState.json');
const logger = createLogger('sessionManager.js');

/**
 * @class SessionManager
 * @description Manages a pool of browser sessions, including their creation, status, and cleanup.
 */
class SessionManager {
  constructor(options = {}) {
    /** @type {Array<object>} */
    this.sessions = [];
    this.nextSessionId = 1;
    this.sessionTimeoutMs = options.sessionTimeoutMs || 30 * 60 * 1000;
    this.cleanupIntervalMs = options.cleanupIntervalMs || 5 * 60 * 1000;
    this.concurrencyPerBrowser = 1;
    this.cleanupInterval = null;

    // Worker allocation lock - prevents race conditions
    this.sessionMap = new Map(); // Optimization: O(1) lookup map
    this.workerLocks = new Map(); // sessionId -> Promise
    this.workerOccupancy = new Map(); // Track worker occupancy for debugging

    this._initPromise = null;
    this.startCleanupTimer();
  }

  /**
   * Initialize SessionManager async components
   * @returns {Promise<void>}
   */
  async init() {
    if (this._initPromise) return this._initPromise;
    this._initPromise = this.loadConfiguration();
    return this._initPromise;
  }

  /**
   * Loads session timeout values from the configuration.
   */
  async loadConfiguration() {
    try {
      const timeouts = await getTimeoutValue('session', {});
      this.sessionTimeoutMs = timeouts.timeoutMs || this.sessionTimeoutMs;
      this.cleanupIntervalMs = timeouts.cleanupIntervalMs || this.cleanupIntervalMs;

      const settings = await getSettings();
      this.concurrencyPerBrowser = settings.concurrencyPerBrowser || 1;

      logger.info(`[SessionManager] Loaded configuration: timeout=${this.sessionTimeoutMs}ms, cleanup=${this.cleanupIntervalMs}ms, concurrency=${this.concurrencyPerBrowser}`);

      if (this.cleanupInterval) {
        this.startCleanupTimer(); // Restarts with new interval
      }
    } catch (error) {
      logger.error('[SessionManager] Failed to load timeout configuration, using defaults:', error.message);
    }
  }

  /**
   * Adds a new browser session to the manager.
   * @param {object} browser - The Playwright browser instance.
   * @param {string} [browserInfo] - A unique identifier for the browser.
   * @returns {string} The ID of the added session.
   */
  addSession(browser, browserInfo) {
    // Priority: browserInfo > generated ID
    const id = browserInfo ? browserInfo : `session-${this.nextSessionId++}`;
    const now = Date.now();

    const workers = Array.from({ length: this.concurrencyPerBrowser }, (_, i) => ({
      id: i,
      status: 'idle',
    }));

    const session = {
      id,
      browser,
      browserInfo,
      workers,
      createdAt: now,
      lastActivity: now,
      managedPages: new Set() // Track pages created by this session
    };

    this.sessions.push(session);
    this.sessionMap.set(id, session);

    if (browserInfo) {
      logger.info(`Added new session: ${id} at ${browserInfo} with ${this.concurrencyPerBrowser} worker slots.`);
    } else {
      logger.info(`Added new session: ${id} with ${this.concurrencyPerBrowser} worker slots.`);
    }

    metricsCollector.recordSessionEvent('created', this.sessions.length);

    return id;
  }

  /**
   * Registers a page as managed by this session.
   * @param {string} sessionId - The session ID.
   * @param {object} page - The Playwright page object.
   */
  registerPage(sessionId, page) {
    const session = this.sessions.find(s => s.id === sessionId);
    if (session) {
      session.managedPages.add(page);
    }
  }

  /**
   * Unregisters a page from this session.
   * @param {string} sessionId - The session ID.
   * @param {object} page - The Playwright page object.
   */
  unregisterPage(sessionId, page) {
    const session = this.sessions.find(s => s.id === sessionId);
    if (session) {
      session.managedPages.delete(page);
    }
  }

  async findAndOccupyIdleWorker(sessionId) {
    // Acquire lock for this session to ensure atomicity
    if (!this.workerLocks.has(sessionId)) {
      this.workerLocks.set(sessionId, Promise.resolve());
    }

    const lockPromise = this.workerLocks.get(sessionId);
    const lockTimeout = 10000; // 10s timeout to prevent deadlocks

    // Create a new promise that waits for the lock and then processes
    const result = await Promise.race([
      new Promise((resolve) => {
        lockPromise.then(async () => {
          const session = this.sessions.find(s => s.id === sessionId);
          if (!session) {
            resolve(null);
            return;
          }

          const worker = session.workers.find(w => w.status === 'idle');
          if (worker) {
            worker.status = 'busy';
            worker.occupiedAt = Date.now();
            worker.occupiedBy = this._getCurrentExecutionContext();

            const occupancyKey = `${sessionId}:${worker.id}`;
            this.workerOccupancy.set(occupancyKey, {
              startTime: Date.now(),
              context: worker.occupiedBy
            });

            logger.debug(`[SessionManager][${sessionId}] Occupied worker ${worker.id}`);
            resolve(worker);
            return;
          }

          logger.debug(`[SessionManager][${sessionId}] No idle workers available`);
          resolve(null);
        });
      }),
      new Promise((_, reject) => setTimeout(() => reject(new Error(`Worker lock timeout for session ${sessionId}`)), lockTimeout))
    ]);

    return result;
  }

  /**
    * Releases a worker in a specific session, setting its status to idle.
    * Uses atomic locking to prevent race conditions.
    * @param {string} sessionId - The ID of the session.
    * @param {number} workerId - The ID of the worker to release.
    */
  async releaseWorker(sessionId, workerId) {
    const session = this.sessions.find(s => s.id === sessionId);
    if (!session) {
      logger.warn(`[SessionManager] Session ${sessionId} not found for releaseWorker`);
      return;
    }

    if (!this.workerLocks.has(sessionId)) {
      this.workerLocks.set(sessionId, Promise.resolve());
    }

    const lockPromise = this.workerLocks.get(sessionId);

    await lockPromise.then(() => {
      const worker = session.workers.find(w => w.id === workerId);
      if (worker && worker.status === 'busy') {
        worker.status = 'idle';
        worker.occupiedAt = null;
        worker.occupiedBy = null;
        session.lastActivity = Date.now();

        const occupancyKey = `${sessionId}:${workerId}`;
        this.workerOccupancy.delete(occupancyKey);
        logger.debug(`[SessionManager][${sessionId}] Released worker ${workerId}`);
      } else {
        logger.warn(`[SessionManager][${sessionId}] Worker ${workerId} not found or not busy`);
      }
    });
  }

  /**
    * Gets the current execution context for debugging.
    * @private
    */
  _getCurrentExecutionContext() {
    try {
      // Try to get stack trace info
      const stack = new Error().stack;
      if (stack) {
        // Extract useful context from stack
        const lines = stack.split('\n').slice(2, 4); // Skip Error and this function
        return lines.map(line => line.trim()).join(' | ');
      }
    } catch (e) {
      // Fallback to basic info
    }
    return 'unknown';
  }

  /**
    * Gets occupancy information for debugging.
    * @param {string} sessionId - The session ID.
    * @returns {object} Occupancy information.
    */
  getWorkerOccupancy(sessionId) {
    const occupancy = {};
    for (const [key, info] of this.workerOccupancy) {
      if (key.startsWith(`${sessionId}:`)) {
        const workerId = key.split(':')[1];
        occupancy[workerId] = {
          duration: Date.now() - info.startTime,
          context: info.context
        };
      }
    }
    return occupancy;
  }

  /**
    * Checks if any workers are stuck (occupied for too long).
    * @param {number} thresholdMs - Threshold in milliseconds.
    * @returns {object[]} List of stuck workers.
    */
  getStuckWorkers(thresholdMs = 60000) {
    const stuck = [];
    const now = Date.now();

    for (const [key, info] of this.workerOccupancy) {
      const duration = now - info.startTime;
      if (duration > thresholdMs) {
        const [sessionId, workerId] = key.split(':');
        stuck.push({
          sessionId,
          workerId: parseInt(workerId),
          duration,
          context: info.context
        });
      }
    }

    return stuck;
  }

  /**
   * Removes a session from the manager.
   * @param {string} id - The ID of the session to remove.
   * @returns {boolean} True if the session was found and removed, false otherwise.
   */
  removeSession(id) {
    const initialLength = this.sessions.length;
    this.sessions = this.sessions.filter(session => session.id !== id);
    if (this.sessions.length < initialLength) {
      this.sessionMap.delete(id);
      logger.info(`Removed session: ${id}`);

      metricsCollector.recordSessionEvent('closed', this.sessions.length);

      return true;
    }
    logger.warn(`Session ${id} not found for removal.`);
    return false;
  }

  /**
   * Gets the number of active sessions.
   * @type {number}
   */
  get activeSessionsCount() {
    return this.sessions.length;
  }

  /**
   * Gets all sessions.
   * @returns {object[]} An array of all session objects.
   */
  getAllSessions() {
    return this.sessions;
  }

  /**
   * Starts the cleanup timer to remove timed-out sessions.
   * @private
   */
  startCleanupTimer() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }

    this.cleanupInterval = setInterval(() => {
      this.cleanupTimedOutSessions();
    }, this.cleanupIntervalMs);

    logger.info(`Started cleanup timer with ${this.cleanupIntervalMs}ms interval`);
  }

  /**
   * Stops the cleanup timer.
   */
  stopCleanupTimer() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
      logger.info(`Stopped cleanup timer`);
    }
  }

  /**
   * Removes sessions that have timed out.
   * @returns {Promise<number>} The number of sessions that were removed.
   */
  async cleanupTimedOutSessions() {
    const now = Date.now();
    const toRemove = [];
    const remaining = [];

    for (const session of this.sessions) {
      const sessionAge = now - session.lastActivity;
      if (sessionAge > this.sessionTimeoutMs) {
        toRemove.push(session);
      } else {
        remaining.push(session);
      }
    }

    if (toRemove.length === 0) return 0;

    logger.info(`[SessionManager] Cleaning up ${toRemove.length} timed-out sessions...`);

    // Update local state first to prevent re-processing
    this.sessions = remaining;
    
    // Sync map
    toRemove.forEach(s => this.sessionMap.delete(s.id));

    const closePromises = toRemove.map(async (session) => {
      logger.info(`[SessionManager] Closing timed-out session: ${session.id}`);
      await this.closeManagedPages(session);
      await this.closeSessionBrowser(session);
    });

    await Promise.allSettled(closePromises);

    logger.info(`[SessionManager] Cleanup completed. Removed ${toRemove.length} sessions.`);
    return toRemove.length;
  }

  /**
   * Safely closes the browser instance for a session.
   * @param {object} session - The session object.
   * @private
   */
  async closeSessionBrowser(session) {
    try {
      if (session.browser && typeof session.browser.close === 'function') {
        await session.browser.close();
        logger.info(`Closed browser for session ${session.id}`);
      }
    } catch (error) {
      logger.error(`Error closing browser for session ${session.id}:`, error.message);
    }
  }

  /**
   * Saves the current session state to a file.
   * @returns {Promise<void>}
   */
  async saveSessionState() {
    try {
      const dataDir = path.dirname(SESSION_STATE_FILE);
      await fs.mkdir(dataDir, { recursive: true });

      const sessionData = this.sessions.map(session => ({
        id: session.id,
        browserInfo: session.browserInfo,
        workers: session.workers,
        createdAt: session.createdAt,
        lastActivity: session.lastActivity
      }));

      const state = {
        sessions: sessionData,
        nextSessionId: this.nextSessionId,
        savedAt: Date.now()
      };

      await fs.writeFile(SESSION_STATE_FILE, JSON.stringify(state, null, 2));
      logger.info(`Saved session state for ${sessionData.length} sessions`);
    } catch (error) {
      logger.error(`Failed to save session state:`, error.message);
    }
  }

  /**
   * Loads the session state from a file.
   * @returns {Promise<object | null>} A promise that resolves with the loaded state, or null if no state is found.
   */
  async loadSessionState() {
    try {
      const data = await fs.readFile(SESSION_STATE_FILE, 'utf8');
      const state = JSON.parse(data);

      logger.info(`Loaded session state with ${state.sessions?.length || 0} sessions`);

      if (state.sessions) {
        this.nextSessionId = state.nextSessionId || 1;
        // Rebuild map if sessions are loaded (though usually loadSessionState is not used to restore runtime objects fully)
        // Note: The loaded sessions don't have browser instances, so they are not fully functional yet.
        // Usually we would iterate and add them, but here we just return state.
        logger.info(`Next session ID set to ${this.nextSessionId}`);
      }

      return state;
    } catch (error) {
      if (error.code !== 'ENOENT') {
        logger.error(`Failed to load session state:`, error.message);
      }
      return null;
    }
  }

  /**
   * Gets session metadata.
   * @returns {object[]} An array of session metadata objects.
   */
  getSessionMetadata() {
    return this.sessions.map(session => ({
      id: session.id,
      browserInfo: session.browserInfo,
      workers: session.workers,
      createdAt: session.createdAt,
      lastActivity: session.lastActivity,
      age: Date.now() - session.createdAt
    }));
  }

  /**
   * Safely closes only the pages managed (created) by this session.
   * @param {object} session - The session object.
   * @private
   */
  async closeManagedPages(session) {
    try {
      if (session.managedPages && session.managedPages.size > 0) {
        logger.info(`Closing ${session.managedPages.size} managed pages for session ${session.id}...`);

        const closePromises = Array.from(session.managedPages).map(async (page, index) => {
          try {
            await page.close();
          } catch (e) {
            // Ignore errors if page is already closed
            logger.debug(`[${session.id}] Error closing managed page: ${e.message}`);
          }
        });

        await Promise.all(closePromises);
        session.managedPages.clear();
      }
    } catch (error) {
      logger.error(`Error closing managed pages for session ${session.id}:`, error.message);
    }
  }

  /**
   * Gracefully shuts down all sessions.
   * @returns {Promise<void>}
   */
  async shutdown() {
    logger.info(`Shutting down ${this.sessions.length} sessions...`);

    this.stopCleanupTimer();

    await this.saveSessionState();

    // Close managed pages first, then the browser connection
    const closePromises = this.sessions.map(async (session) => {
      await this.closeManagedPages(session);
      await this.closeSessionBrowser(session);
    });

    await Promise.allSettled(closePromises);

    this.sessions = [];
    logger.info(`Shutdown completed`);
  }
}

export default SessionManager;

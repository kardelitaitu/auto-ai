import { createLogger } from '../utils/logger.js';
import VisionInterpreter from './vision-interpreter.js';
import LocalClient from './local-client.js';
import StuckDetector from './stuck-detector.js';
import PromptBuilder from './prompt-builder.js';

const logger = createLogger('agent-cortex.js');

// Constants
const HISTORY_WINDOW = 5;
const MAX_HISTORY_SIZE = 50;

class AgentCortex {
    constructor(sessionId, goal, steps = []) {
        this.sessionId = sessionId;
        this.goal = goal;
        this.steps = steps;

        this.history = [];
        this.consecutiveFailures = 0;

        // Step State
        this.currentStep = steps.length > 0 ? 1 : 0;
        this.stepAttempts = 0;
        this.maxStepAttempts = 5;

        // Modular Components
        this.interpreter = new VisionInterpreter();
        this.llmClient = new LocalClient();
        this.stuckDetector = new StuckDetector(3);
        this.promptBuilder = new PromptBuilder(goal, steps);

        logger.debug(`[${this.sessionId}] [Cortex] Initialized for goal: "${goal}"`);
    }

    /**
     * Plan the next action based on visual and semantic state.
     */
    async planNextStep(visionPacket, semanticTree) {
        // 1. Termination Checks
        if (this.steps.length > 0 && this.currentStep > this.steps.length) {
            return this._terminate('All methodology steps completed');
        }

        if (this._isTerminationStep()) {
            return this._terminate(`Reached termination step: "${this.steps[this.currentStep - 1]}"`);
        }

        // 2. Health Check
        const stuckStatus = this.stuckDetector.check(visionPacket.base64);

        // 3. Think
        const historyStr = this._formatHistory();
        const prompt = this.promptBuilder.build({
            history: historyStr,
            visionPacket,
            currentStep: this.currentStep,
            stuckCounter: stuckStatus.counter,
            consecutiveFailures: this.consecutiveFailures
        });

        logger.info(`[${this.sessionId}] [Cortex] Thinking...`);
        const response = await this.llmClient.sendRequest({
            prompt,
            vision: visionPacket.base64,
            temperature: 0.1
        });

        if (!response.success) {
            throw new Error(`Cortex Brain Freeze: ${response.error}`);
        }

        // 4. Parse & Enforce
        const plan = this.interpreter.parseResponse(response.content);
        if (!plan.success) {
            return {
                type: 'wait',
                duration: 2000,
                description: `Recovery: ${plan.error || 'Invalid thought format'}`
            };
        }

        if (plan.data.thought) {
            logger.info(`[${this.sessionId}] 🧠 THOUGHT: ${plan.data.thought}`);
        }

        this._validateStepProgression(plan.data);

        return plan.data;
    }

    /**
     * Record result and update internal state.
     */
    recordResult(action, success, message) {
        this.history.push({
            type: action.type,
            description: action.description,
            success,
            result: message,
            timestamp: Date.now()
        });

        if (this.history.length > MAX_HISTORY_SIZE) {
            this.history = this.history.slice(-MAX_HISTORY_SIZE);
        }

        if (success) {
            this.consecutiveFailures = 0;
            this._detectStepCompletion(action);
        } else {
            this.consecutiveFailures++;
        }
    }

    _isTerminationStep() {
        if (this.steps.length === 0 || this.currentStep > this.steps.length) return false;
        const text = this.steps[this.currentStep - 1].toLowerCase();
        return ['done', 'complete', 'finish', 'end', 'terminate'].some(kw => text.includes(kw));
    }

    _terminate(reason) {
        logger.success(`[${this.sessionId}] [Cortex] 🏁 ${reason}`);
        return {
            type: 'terminate',
            reason,
            actions: [{ type: 'terminate', reason }]
        };
    }

    _validateStepProgression(planData) {
        if (this.steps.length === 0) return;

        this.stepAttempts++;
        planData.currentStep = this.currentStep;

        if (this.stepAttempts >= this.maxStepAttempts) {
            logger.warn(`[${this.sessionId}] [Cortex] ⏭️ Force advancing from stuck step ${this.currentStep}`);
            this.advanceStep();
        }
    }

    _detectStepCompletion(lastAction) {
        if (this.currentStep > this.steps.length) return;

        const desc = this.steps[this.currentStep - 1].toLowerCase();
        const type = lastAction.type;

        // Heuristics for auto-advancing steps
        const isNav = desc.includes('navigate') && type === 'navigate';
        const isWait = desc.includes('wait') && type === 'wait';
        const isActionMatch = ['click', 'type', 'scroll', 'press'].some(v => desc.includes(v) && type === v);

        if (isNav || isWait || isActionMatch) {
            this.advanceStep();
        }
    }

    advanceStep() {
        if (this.currentStep <= this.steps.length) {
            this.currentStep++;
            this.stepAttempts = 0;
            logger.info(`[${this.sessionId}] [Cortex] 📋 Current Step: ${this.currentStep}/${this.steps.length}`);
        }
    }

    _formatHistory() {
        if (this.history.length === 0) return "No previous actions.";
        return this.history.slice(-HISTORY_WINDOW).map((h, i) =>
            `${i + 1}. ${h.type} (${h.description}) -> ${h.success ? 'OK' : 'FAIL'} [${h.result}]`
        ).join('\n');
    }
}

export default AgentCortex;

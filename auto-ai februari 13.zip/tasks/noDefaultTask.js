
export const notDefault = () => {};

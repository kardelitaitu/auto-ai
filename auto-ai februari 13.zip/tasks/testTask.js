
export default async function testTask(page, payload) {
  return true;
}


export const someExport = 'value';
// No default export

/**
 * Async Queue Manager for AI Operations
 * Handles race conditions and provides timeout/fallback mechanisms
 * @module utils/async-queue
 */

import { createLogger } from './logger.js';

const logger = createLogger('async-queue.js');

export class AsyncQueue {
    constructor(options = {}) {
        this.maxConcurrent = options.maxConcurrent ?? 3;
        this.maxQueueSize = options.maxQueueSize ?? 50;
        this.defaultTimeout = options.defaultTimeout ?? 20000;

        this.queue = [];
        this.active = new Map();
        this.processing = false;
        this.processedCount = 0;
        this.failedCount = 0;
        this.timedOutCount = 0;

        this.stats = {
            totalAdded: 0,
            totalCompleted: 0,
            totalFailed: 0,
            totalTimedOut: 0,
            averageWaitTime: 0,
            averageProcessingTime: 0
        };

        logger.info(`[AsyncQueue] Initialized (maxConcurrent: ${this.maxConcurrent}, maxQueueSize: ${this.maxQueueSize}, defaultTimeout: ${this.defaultTimeout}ms)`);
    }

    /**
     * Add a task to the queue
     * @param {Function} taskFn - Async function to execute
     * @param {object} options - Task options
     * @returns {Promise} Result of the task
     */
    async add(taskFn, options = {}) {
        const id = `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        const timeout = options.timeout ?? this.defaultTimeout;
        const priority = options.priority ?? 0;
        const taskName = options.name || 'unnamed';

        if (this.queue.length + this.active.size >= this.maxQueueSize) {
            logger.warn(`[AsyncQueue] Queue full, rejecting task: ${taskName}`);
            return { success: false, reason: 'queue_full', taskName: id };
        }

        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            this.queue.push({
                id,
                taskFn,
                timeout,
                priority,
                taskName,
                resolve,
                reject,
                enqueueTime: startTime
            });
            this.stats.totalAdded++;
            this._processQueue();
        });
    }

    /**
     * Process items in the queue
     */
    async _processQueue() {
        if (this.processing) return;
        this.processing = true;

        while (this.queue.length > 0 && this.active.size < this.maxConcurrent) {
            // Sort by priority (higher priority first)
            this.queue.sort((a, b) => b.priority - a.priority);

            const item = this.queue.shift();
            const startTime = Date.now();

            logger.debug(`[AsyncQueue] Starting task: ${item.taskName} (queue: ${this.queue.length}, active: ${this.active.size})`);

            this.active.set(item.id, {
                ...item,
                startTime
            });

            try {
                const result = await Promise.race([
                    this._executeTask(item),
                    this._createTimeout(item)
                ]);

                const processingTime = Date.now() - startTime;
                this.stats.totalCompleted++;
                this._updateAverageStats('processing', processingTime);

                logger.info(`[AsyncQueue] Completed task: ${item.taskName} in ${processingTime}ms`);
                item.resolve({ success: true, result, taskName: item.taskName, processingTime });

            } catch (error) {
                const isTimeout = error.message === 'timeout';
                const processingTime = Date.now() - startTime;

                if (isTimeout) {
                    this.stats.totalTimedOut++;
                    this.timedOutCount++;
                    logger.warn(`[AsyncQueue] Task timed out: ${item.taskName} after ${processingTime}ms`);
                } else {
                    this.stats.totalFailed++;
                    this.failedCount++;
                    logger.error(`[AsyncQueue] Task failed: ${item.taskName} - ${error.message}`);
                }

                item.resolve({
                    success: false,
                    reason: isTimeout ? 'timeout' : 'error',
                    error: error.message,
                    taskName: item.taskName,
                    processingTime
                });

            } finally {
                this.active.delete(item.id);
                this.processedCount++;
            }
        }

        this.processing = false;
    }

    /**
     * Execute a task with timeout
     */
    async _executeTask(item) {
        return await item.taskFn();
    }

    /**
     * Create a timeout promise
     */
    _createTimeout(item) {
        return new Promise((_, reject) => {
            setTimeout(() => {
                reject(new Error('timeout'));
            }, item.timeout);
        });
    }

    /**
     * Update average statistics
     */
    _updateAverageStats(type, value) {
        const count = this.stats.totalCompleted + this.stats.totalFailed;
        if (count <= 1) {
            if (type === 'processing') {
                this.stats.averageProcessingTime = value;
            }
            return;
        }

        if (type === 'processing') {
            const total = this.stats.averageProcessingTime * (count - 1) + value;
            this.stats.averageProcessingTime = total / count;
        }
    }

    /**
     * Get queue status
     */
    getStatus() {
        return {
            queueLength: this.queue.length,
            activeCount: this.active.size,
            maxConcurrent: this.maxConcurrent,
            isProcessing: this.processing,
            processed: this.processedCount,
            failed: this.failedCount,
            timedOut: this.timedOutCount
        };
    }

    /**
     * Get detailed statistics
     */
    getStats() {
        return {
            ...this.stats,
            queueStatus: this.getStatus(),
            utilizationPercent: this.active.size > 0
                ? Math.round((this.active.size / this.maxConcurrent) * 100)
                : 0
        };
    }

    /**
     * Clear the queue
     */
    clear() {
        const dropped = this.queue.length;
        this.queue = [];

        logger.info(`[AsyncQueue] Cleared queue (dropped ${dropped} tasks)`);

        return { dropped };
    }

    /**
     * Check if queue is healthy
     */
    isHealthy() {
        return this.failedCount < 5 && this.timedOutCount < 10;
    }

    /**
     * Get health status
     */
    getHealth() {
        return {
            healthy: this.isHealthy(),
            failedCount: this.failedCount,
            timedOutCount: this.timedOutCount,
            queueLength: this.queue.length
        };
    }
}

/**
 * Dive Queue - Specialized queue for tweet dive operations
 * Extends AsyncQueue with dive-specific features
 */
export class DiveQueue extends AsyncQueue {
    constructor(options = {}) {
        super({
            maxConcurrent: options.maxConcurrent ?? 10,
            maxQueueSize: options.maxQueueSize ?? 30,
            defaultTimeout: options.defaultTimeout ?? 20000
        });

        this.fallbackEngagement = options.fallbackEngagement ?? true;
        this.quickMode = false;

        // Engagement tracking
        this.engagementLimits = {
            replies: options.replies ?? 3,
            retweets: options.retweets ?? 1,
            quotes: options.quotes ?? 1,
            likes: options.likes ?? 5,
            follows: options.follows ?? 2,
            bookmarks: options.bookmarks ?? 2
        };

        this.engagementCounters = {
            replies: 0,
            retweets: 0,
            quotes: 0,
            likes: 0,
            follows: 0,
            bookmarks: 0
        };

        logger.info(`[DiveQueue] Initialized with engagement limits: ${JSON.stringify(this.engagementLimits)}`);
    }

    /**
     * Check if engagement limit allows action
     */
    canEngage(action) {
        const limit = this.engagementLimits[action] ?? Infinity;
        const current = this.engagementCounters[action] ?? 0;
        return current < limit;
    }

    /**
     * Record engagement action
     */
    recordEngagement(action) {
        if (this.engagementCounters.hasOwnProperty(action)) {
            this.engagementCounters[action]++;
            logger.debug(`[DiveQueue] Engagement: ${action} (${this.engagementCounters[action]}/${this.engagementLimits[action]})`);
            return true;
        }
        return false;
    }

    /**
     * Get engagement progress
     */
    getEngagementProgress() {
        const progress = {};
        for (const action of Object.keys(this.engagementLimits)) {
            progress[action] = {
                current: this.engagementCounters[action],
                limit: this.engagementLimits[action],
                remaining: Math.max(0, this.engagementLimits[action] - this.engagementCounters[action]),
                percentUsed: Math.round((this.engagementCounters[action] / this.engagementLimits[action]) * 100)
            };
        }
        return progress;
    }

    /**
     * Add dive task with fallback support
     */
    async addDive(diveFn, fallbackFn, options = {}) {
        const taskName = options.taskName || `dive_${Date.now()}`;

        return this.add(async () => {
            try {
                // Try primary dive function
                const result = await Promise.race([
                    diveFn(),
                    new Promise((_, reject) =>
                        setTimeout(() => reject(new Error('dive_timeout')), options.timeout ?? 5000)
                    )
                ]);

                return {
                    success: true,
                    result,
                    fallbackUsed: false,
                    taskName
                };

            } catch (error) {
                logger.warn(`[DiveQueue] Dive failed: ${error.message}, checking fallback...`);

                // Check if we should use fallback
                if (this.fallbackEngagement && fallbackFn) {
                    try {
                        const fallbackResult = await fallbackFn();
                        return {
                            success: false,
                            fallbackUsed: true,
                            fallbackResult,
                            error: error.message,
                            taskName
                        };
                    } catch (fallbackError) {
                        logger.error(`[DiveQueue] Fallback also failed: ${fallbackError.message}`);
                        return {
                            success: false,
                            fallbackUsed: false,
                            error: `${error.message}; fallback: ${fallbackError.message}`,
                            taskName
                        };
                    }
                }

                return {
                    success: false,
                    fallbackUsed: false,
                    error: error.message,
                    taskName
                };
            }
        }, {
            ...options,
            name: taskName
        });
    }

    /**
     * Enable quick mode (reduced timeouts for faster fallback)
     */
    enableQuickMode() {
        this.quickMode = true;
        this.defaultTimeout = 3000;
        logger.info(`[DiveQueue] Quick mode enabled (timeout: ${this.defaultTimeout}ms)`);
    }

    /**
     * Disable quick mode
     */
    disableQuickMode() {
        this.quickMode = false;
        this.defaultTimeout = 5000;
        logger.info(`[DiveQueue] Quick mode disabled (timeout: ${this.defaultTimeout}ms)`);
    }

    /**
     * Get comprehensive queue status including engagement
     */
    getFullStatus() {
        return {
            queue: this.getStatus(),
            engagement: this.getEngagementProgress(),
            quickMode: this.quickMode,
            health: this.getHealth()
        };
    }

    /**
     * Reset engagement counters
     */
    resetEngagement() {
        for (const key of Object.keys(this.engagementCounters)) {
            this.engagementCounters[key] = 0;
        }
        logger.info(`[DiveQueue] Engagement counters reset`);
    }

    /**
     * Update engagement limits at runtime
     */
    updateEngagementLimits(newLimits) {
        this.engagementLimits = { ...this.engagementLimits, ...newLimits };
        logger.info(`[DiveQueue] Updated engagement limits: ${JSON.stringify(this.engagementLimits)}`);
    }
}

export default AsyncQueue;

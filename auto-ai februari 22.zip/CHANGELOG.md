# Changelog

## Unreleased
- Added centralized task dispatch mode to share tasks across sessions.
- Added unit and integration coverage for dispatch modes.
- Added page pooling with optional shared context reuse controls.

# Connectors README

This directory contains modules responsible for discovering and interrogating different types of browser instances.

Each module in `discovery/` adheres to the `baseDiscover.js` interface.

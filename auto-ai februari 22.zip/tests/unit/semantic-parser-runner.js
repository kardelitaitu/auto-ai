require('@babel/register')();
require('./semantic-parser.test.js');